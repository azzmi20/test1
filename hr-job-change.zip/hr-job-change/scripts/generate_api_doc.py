"""Génère docs/GLOSSAIRE_FONCTIONS.md à partir des docstrings du code.

Usage : python scripts/generate_api_doc.py

La documentation est *extraite* du code (module ``ast``, sans importer le
projet) : elle ne peut donc pas devenir obsolète si on relance le script.
"""

from __future__ import annotations

import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src" / "hr_pipeline"
OUT = ROOT / "docs" / "GLOSSAIRE_FONCTIONS.md"

ORDER = [
    "config",
    "schemas",
    "data_loader",
    "preprocessing",
    "features",
    "model",
    "evaluation",
    "visualization",
    "pipeline",
    "reporting",
    "synthetic",
    "logging_utils",
    "cli",
]


def first_line(doc: str | None) -> str:
    """Première ligne d'une docstring (vide si absente)."""
    return (doc or "").strip().split("\n")[0].replace("|", "\\|")


def signature(node: ast.FunctionDef) -> str:
    """Signature lisible : ``(a: int, b: str = 'x') -> bool``."""
    args = ast.unparse(node.args)
    returns = f" -> {ast.unparse(node.returns)}" if node.returns else ""
    return f"({args}){returns}".replace("|", "\\|")


def render_module(name: str) -> str:
    """Rend la section Markdown d'un module."""
    path = SRC / f"{name}.py"
    tree = ast.parse(path.read_text(encoding="utf-8"))
    lines = [f"## `{name}.py`", "", f"_{first_line(ast.get_docstring(tree))}_", ""]

    functions = [
        n for n in tree.body if isinstance(n, ast.FunctionDef) and not n.name.startswith("_")
    ]
    classes = [n for n in tree.body if isinstance(n, ast.ClassDef) and not n.name.startswith("_")]

    if functions:
        lines += ["| Fonction | Signature | Rôle |", "|---|---|---|"]
        for fn in functions:
            lines.append(
                f"| `def {fn.name}` | `{signature(fn)}` | {first_line(ast.get_docstring(fn))} |"
            )
        lines.append("")
    if classes:
        lines += ["| Classe | Rôle |", "|---|---|"]
        for cls in classes:
            lines.append(f"| `class {cls.name}` | {first_line(ast.get_docstring(cls))} |")
        lines.append("")
    return "\n".join(lines)


def main() -> None:
    """Écrit le fichier de documentation."""
    parts = [
        "# Glossaire des fonctions (`def`) et classes du projet",
        "",
        "> Fichier **généré automatiquement** par `scripts/generate_api_doc.py` "
        "à partir des docstrings. Ne pas modifier à la main.",
        "",
    ]
    total_fn = total_cls = 0
    for name in ORDER:
        tree = ast.parse((SRC / f"{name}.py").read_text(encoding="utf-8"))
        total_fn += sum(
            isinstance(n, ast.FunctionDef) and not n.name.startswith("_") for n in tree.body
        )
        total_cls += sum(
            isinstance(n, ast.ClassDef) and not n.name.startswith("_") for n in tree.body
        )
        parts.append(render_module(name))
    parts.insert(
        3,
        f"**{total_fn} fonctions publiques et {total_cls} classes** "
        f"réparties en {len(ORDER)} modules.\n",
    )
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text("\n".join(parts), encoding="utf-8")
    print(f"écrit {OUT} ({total_fn} fonctions, {total_cls} classes)")


if __name__ == "__main__":
    main()
