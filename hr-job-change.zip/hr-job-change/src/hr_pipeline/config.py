"""Chargement et validation de la configuration.

Principe de la séparation code / configuration :

1. ``configs/config.yaml`` contient les valeurs par défaut versionnées ;
2. le fichier ``.env`` (non versionné) contient les valeurs propres à une
   machine ou à un environnement (dev / test / prod) ;
3. les variables d'environnement ``HR_*`` surchargent le YAML ;
4. le résultat est validé par des modèles Pydantic : une configuration
   incohérente (``test_size = 3``, ``env = "preprod"``...) échoue **au
   démarrage** avec un message clair, pas au milieu de l'entraînement.
"""

from __future__ import annotations

import os
from collections.abc import Callable
from pathlib import Path
from typing import Any, Literal

import yaml
from dotenv import load_dotenv
from pydantic import BaseModel, ConfigDict, Field, model_validator

PROJECT_ROOT: Path = Path(__file__).resolve().parents[2]
DEFAULT_CONFIG_PATH: Path = PROJECT_ROOT / "configs" / "config.yaml"

ModelName = Literal["logistic_regression", "random_forest", "gradient_boosting"]


class _Strict(BaseModel):
    """Base commune : refuse les clés inconnues (détecte les fautes de frappe)."""

    model_config = ConfigDict(extra="forbid")


class ProjectConfig(_Strict):
    """Paramètres généraux du projet."""

    name: str
    env: Literal["dev", "test", "prod"] = "dev"
    random_seed: int = Field(default=42, ge=0)
    log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR"] = "INFO"


class PathsConfig(_Strict):
    """Chemins relatifs à la racine du projet."""

    raw_dir: str
    processed_dir: str
    models_dir: str
    figures_dir: str
    train_file: str
    test_file: str
    submission_template: str
    model_file: str
    metrics_file: str
    submission_file: str
    rejected_file: str


class ValidationConfig(_Strict):
    """Bornes utilisées par le schéma Pydantic de validation des données."""

    max_rejection_rate: float = Field(default=0.05, ge=0.0, le=1.0)
    cdi_min: float = 0.0
    cdi_max: float = 1.0
    training_hours_min: int = Field(default=1, ge=0)
    training_hours_max: int = Field(default=1000, ge=1)

    @model_validator(mode="after")
    def _check_bounds(self) -> ValidationConfig:
        if self.cdi_min >= self.cdi_max:
            raise ValueError("cdi_min doit être strictement inférieur à cdi_max")
        if self.training_hours_min >= self.training_hours_max:
            raise ValueError("training_hours_min doit être < training_hours_max")
        return self


class FeaturesConfig(_Strict):
    """Description des colonnes utilisées par le modèle."""

    target: str
    id_column: str
    drop_columns: list[str]
    numeric: list[str]
    categorical: list[str]
    binary_flags: list[str]
    city_min_frequency: int = Field(default=50, ge=1)


class ModelConfig(_Strict):
    """Choix du modèle et hyper-paramètres."""

    name: ModelName
    test_size: float = Field(gt=0.0, lt=1.0)
    cv_folds: int = Field(ge=2)
    decision_threshold: float = Field(gt=0.0, lt=1.0)
    candidates: dict[str, dict[str, Any]]

    @model_validator(mode="after")
    def _check_candidates(self) -> ModelConfig:
        if self.name not in self.candidates:
            raise ValueError(f"Le modèle '{self.name}' n'a pas de bloc dans 'candidates'")
        return self


class AppConfig(_Strict):
    """Configuration complète de l'application."""

    project: ProjectConfig
    paths: PathsConfig
    validation: ValidationConfig
    features: FeaturesConfig
    model: ModelConfig
    root: Path = PROJECT_ROOT

    # -- helpers de chemins ------------------------------------------------
    def resolve(self, relative: str | Path) -> Path:
        """Transforme un chemin relatif à la racine du projet en chemin absolu."""
        path = Path(relative)
        return path if path.is_absolute() else self.root / path

    @property
    def train_path(self) -> Path:
        return self.resolve(Path(self.paths.raw_dir) / self.paths.train_file)

    @property
    def test_path(self) -> Path:
        return self.resolve(Path(self.paths.raw_dir) / self.paths.test_file)

    @property
    def template_path(self) -> Path:
        return self.resolve(Path(self.paths.raw_dir) / self.paths.submission_template)

    @property
    def model_path(self) -> Path:
        return self.resolve(Path(self.paths.models_dir) / self.paths.model_file)

    @property
    def metrics_path(self) -> Path:
        return self.resolve(Path(self.paths.models_dir) / self.paths.metrics_file)

    @property
    def submission_path(self) -> Path:
        return self.resolve(Path(self.paths.processed_dir) / self.paths.submission_file)

    @property
    def rejected_path(self) -> Path:
        return self.resolve(Path(self.paths.processed_dir) / self.paths.rejected_file)

    @property
    def figures_path(self) -> Path:
        return self.resolve(self.paths.figures_dir)


# ---------------------------------------------------------------------------
# Surcharges par variables d'environnement
# ---------------------------------------------------------------------------

# variable d'environnement -> (section YAML, clé, fonction de conversion)
_ENV_OVERRIDES: dict[str, tuple[str, str, Callable[[str], Any]]] = {
    "HR_ENV": ("project", "env", str),
    "HR_LOG_LEVEL": ("project", "log_level", str.upper),
    "HR_RANDOM_SEED": ("project", "random_seed", int),
    "HR_MAX_REJECTION_RATE": ("validation", "max_rejection_rate", float),
}


def apply_env_overrides(
    raw: dict[str, Any], environ: dict[str, str] | None = None
) -> dict[str, Any]:
    """Applique les variables ``HR_*`` par-dessus le dictionnaire issu du YAML.

    Args:
        raw: configuration brute lue dans le YAML (modifiée en place puis renvoyée).
        environ: environnement à utiliser (``os.environ`` par défaut, utile aux tests).

    Returns:
        Le dictionnaire de configuration surchargé.
    """
    env = os.environ if environ is None else environ
    for var, (section, key, cast) in _ENV_OVERRIDES.items():
        value = env.get(var)
        if value not in (None, ""):
            raw.setdefault(section, {})[key] = cast(value)
    return raw


def load_config(
    path: str | Path | None = None,
    environ: dict[str, str] | None = None,
    load_env_file: bool = True,
) -> AppConfig:
    """Charge, surcharge puis valide la configuration.

    Args:
        path: chemin du fichier YAML (``configs/config.yaml`` par défaut).
        environ: environnement alternatif (tests). ``None`` = ``os.environ``.
        load_env_file: si ``True``, lit d'abord le fichier ``.env`` du projet.

    Returns:
        Une instance validée d'``AppConfig``.

    Raises:
        FileNotFoundError: si le YAML n'existe pas.
        pydantic.ValidationError: si la configuration est invalide.
    """
    config_path = Path(path) if path else DEFAULT_CONFIG_PATH
    if not config_path.exists():
        raise FileNotFoundError(f"Fichier de configuration introuvable : {config_path}")

    root_override = (environ or os.environ).get("HR_PROJECT_ROOT")
    root = Path(root_override) if root_override else PROJECT_ROOT

    if load_env_file and environ is None:
        load_dotenv(root / ".env", override=False)

    with config_path.open(encoding="utf-8") as handle:
        raw: dict[str, Any] = yaml.safe_load(handle) or {}

    raw = apply_env_overrides(raw, environ)
    raw["root"] = root
    return AppConfig.model_validate(raw)
