"""Interface en ligne de commande.

Exemples ::

    python -m hr_pipeline validate
    python -m hr_pipeline compare
    python -m hr_pipeline train --model random_forest
    python -m hr_pipeline predict
    python -m hr_pipeline figures
"""

from __future__ import annotations

import argparse
import json
import sys
from collections.abc import Sequence

from pydantic import ValidationError

from hr_pipeline.config import AppConfig, load_config
from hr_pipeline.logging_utils import get_logger, setup_logging
from hr_pipeline.model import SUPPORTED_MODELS
from hr_pipeline.schemas import DataValidationError

logger = get_logger(__name__)


def build_parser() -> argparse.ArgumentParser:
    """Construit le parseur d'arguments (une sous-commande par action)."""
    parser = argparse.ArgumentParser(prog="hr-pipeline", description=__doc__.split("\n")[0])
    parser.add_argument("--config", default=None, help="chemin d'un fichier YAML alternatif")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("validate", help="valide les CSV bruts avec le schéma Pydantic")
    sub.add_parser("compare", help="compare les modèles par validation croisée")
    train = sub.add_parser("train", help="entraîne et sauvegarde le modèle")
    train.add_argument("--model", choices=SUPPORTED_MODELS, default=None)
    sub.add_parser("predict", help="génère le fichier de soumission")
    sub.add_parser("figures", help="génère tous les graphiques dans reports/figures/")
    return parser


def cmd_validate(config: AppConfig) -> int:
    """Valide les fichiers train et test, affiche les rapports."""
    from hr_pipeline.data_loader import load_test, load_train
    from hr_pipeline.pipeline import prepare_dataset

    for label, loader in (("train", load_train), ("test", load_test)):
        _, _, report = prepare_dataset(loader(config), config, save_rejected=True)
        print(f"--- {label} ---\n{report.summary()}\n")
    return 0


def cmd_compare(config: AppConfig) -> int:
    """Affiche le tableau de comparaison des modèles."""
    from hr_pipeline.data_loader import load_train
    from hr_pipeline.evaluation import compare_models
    from hr_pipeline.features import split_features_target
    from hr_pipeline.pipeline import prepare_dataset

    clean, _, _ = prepare_dataset(load_train(config), config)
    X, y = split_features_target(clean, config.features)
    print(compare_models(config, X, y).round(4).to_string(index=False))
    return 0


def cmd_train(config: AppConfig, model: str | None) -> int:
    """Entraîne le modèle et affiche les métriques."""
    from hr_pipeline.pipeline import run_training

    result = run_training(config, model_name=model)
    print(json.dumps(result.metrics["validation"], indent=2))
    return 0


def cmd_predict(config: AppConfig) -> int:
    """Écrit le fichier de soumission."""
    from hr_pipeline.pipeline import run_prediction

    submission = run_prediction(config)
    print(f"Soumission écrite : {config.submission_path} ({len(submission)} lignes)")
    return 0


def cmd_figures(config: AppConfig) -> int:
    """Génère tous les graphiques du rapport."""
    from hr_pipeline.reporting import generate_all_figures

    paths = generate_all_figures(config)
    print(f"{len(paths)} figures écrites dans {config.figures_path}")
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    """Point d'entrée. Renvoie un code de sortie (0 = succès)."""
    args = build_parser().parse_args(argv)
    try:
        config = load_config(args.config)
    except (FileNotFoundError, ValidationError) as exc:
        print(f"Configuration invalide : {exc}", file=sys.stderr)
        return 2

    setup_logging(config.project.log_level)
    try:
        if args.command == "validate":
            return cmd_validate(config)
        if args.command == "compare":
            return cmd_compare(config)
        if args.command == "train":
            return cmd_train(config, args.model)
        if args.command == "predict":
            return cmd_predict(config)
        if args.command == "figures":
            return cmd_figures(config)
    except DataValidationError as exc:
        print(f"Données refusées : {exc}", file=sys.stderr)
        return 3
    except FileNotFoundError as exc:
        print(f"Fichier manquant : {exc}", file=sys.stderr)
        return 4
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
