"""Schémas Pydantic : validation stricte des données entrantes (Séquence 2).

Idée centrale : **on ne fait jamais confiance à une donnée qui entre dans le
pipeline**. Chaque ligne du CSV est confrontée à un contrat (``EnrolleeRecord``).
Une ligne qui viole le contrat est *rejetée et tracée* (jamais corrigée en
silence) ; si trop de lignes sont rejetées, le pipeline s'arrête.

Ce que le schéma garantit :

- types corrects (``training_hours`` est un entier, pas ``"abc"``) ;
- bornes respectées (``0 <= city_development_index <= 1``, durée > 0) ;
- modalités autorisées (``gender`` ∈ {Male, Female, Other}, etc.) ;
- absence de colonnes inattendues (``extra="forbid"``) ;
- pas de ``inf`` / ``NaN`` déguisés dans les nombres.

Les valeurs manquantes (``NaN`` pandas) sont **légitimes** pour les colonnes
optionnelles : elles sont converties en ``None`` avant validation.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

import pandas as pd
from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    ValidationError,
    create_model,
    field_validator,
)

from hr_pipeline.config import ValidationConfig
from hr_pipeline.logging_utils import get_logger

logger = get_logger(__name__)

# ---------------------------------------------------------------------------
# Modalités autorisées (reprennent EXACTEMENT les libellés du jeu de données,
# fautes d'orthographe d'origine comprises : « relevent », « 10/49 »).
# ---------------------------------------------------------------------------


class Gender(str, Enum):
    """Genre déclaré du candidat."""

    MALE = "Male"
    FEMALE = "Female"
    OTHER = "Other"


class RelevantExperience(str, Enum):
    """Le candidat a-t-il une expérience pertinente en data science ?"""

    YES = "Has relevent experience"
    NO = "No relevent experience"


class EnrolledUniversity(str, Enum):
    """Type de cursus universitaire en cours."""

    NONE = "no_enrollment"
    FULL_TIME = "Full time course"
    PART_TIME = "Part time course"


class EducationLevel(str, Enum):
    """Niveau d'études le plus élevé."""

    PRIMARY = "Primary School"
    HIGH_SCHOOL = "High School"
    GRADUATE = "Graduate"
    MASTERS = "Masters"
    PHD = "Phd"


class MajorDiscipline(str, Enum):
    """Discipline principale des études supérieures."""

    STEM = "STEM"
    BUSINESS = "Business Degree"
    ARTS = "Arts"
    HUMANITIES = "Humanities"
    NO_MAJOR = "No Major"
    OTHER = "Other"


class CompanySize(str, Enum):
    """Tranche d'effectif de l'entreprise actuelle."""

    S_LT10 = "<10"
    S_10_49 = "10/49"
    S_50_99 = "50-99"
    S_100_500 = "100-500"
    S_500_999 = "500-999"
    S_1000_4999 = "1000-4999"
    S_5000_9999 = "5000-9999"
    S_10000_PLUS = "10000+"


class CompanyType(str, Enum):
    """Type d'entreprise actuelle."""

    PVT_LTD = "Pvt Ltd"
    FUNDED_STARTUP = "Funded Startup"
    EARLY_STARTUP = "Early Stage Startup"
    PUBLIC_SECTOR = "Public Sector"
    NGO = "NGO"
    OTHER = "Other"


EXPERIENCE_VALUES: frozenset[str] = frozenset(["<1", ">20", *[str(i) for i in range(1, 21)]])
LAST_NEW_JOB_VALUES: frozenset[str] = frozenset(["never", "1", "2", "3", "4", ">4"])


# ---------------------------------------------------------------------------
# Schéma d'une ligne
# ---------------------------------------------------------------------------


class EnrolleeRecord(BaseModel):
    """Contrat d'une ligne du fichier ``aug_train.csv`` / ``aug_test.csv``.

    Les champs marqués ``| None = None`` sont optionnels : leur absence
    (valeur manquante) est une information valide, pas une erreur.
    """

    # Validation STRICTE : on ne « répare » rien en silence. Une valeur comme " Male "
    # (espaces parasites) est rejetée, car la validation ne transforme pas les données :
    # l'accepter laisserait passer une modalité fantôme jusqu'à l'encodage one-hot.
    model_config = ConfigDict(
        extra="forbid",  # une colonne inconnue est une erreur
        validate_default=True,
    )

    enrollee_id: int = Field(gt=0, description="Identifiant unique du candidat")
    city: str = Field(pattern=r"^city_\d+$", description="Code ville, ex. city_103")
    city_development_index: float = Field(ge=0.0, le=1.0, allow_inf_nan=False)
    gender: Gender | None = None
    relevent_experience: RelevantExperience
    enrolled_university: EnrolledUniversity | None = None
    education_level: EducationLevel | None = None
    major_discipline: MajorDiscipline | None = None
    experience: str | None = None
    company_size: CompanySize | None = None
    company_type: CompanyType | None = None
    last_new_job: str | None = None
    training_hours: int = Field(ge=1, le=1000)
    target: int | None = Field(default=None, ge=0, le=1)

    @field_validator("experience")
    @classmethod
    def _check_experience(cls, value: str | None) -> str | None:
        """``experience`` doit valoir ``<1``, ``1``…``20`` ou ``>20``."""
        if value is not None and value not in EXPERIENCE_VALUES:
            raise ValueError(f"experience '{value}' hors des modalités autorisées")
        return value

    @field_validator("last_new_job")
    @classmethod
    def _check_last_new_job(cls, value: str | None) -> str | None:
        """``last_new_job`` doit valoir ``never``, ``1``…``4`` ou ``>4``."""
        if value is not None and value not in LAST_NEW_JOB_VALUES:
            raise ValueError(f"last_new_job '{value}' hors des modalités autorisées")
        return value


def build_record_model(cfg: ValidationConfig | None = None) -> type[EnrolleeRecord]:
    """Construit un schéma dont les bornes viennent de la configuration.

    Les bornes (``cdi_min``, ``training_hours_max``...) ne sont donc plus codées
    en dur : on les change dans ``config.yaml`` sans toucher au code.

    Args:
        cfg: bornes de validation (valeurs par défaut si ``None``).

    Returns:
        Une sous-classe d'``EnrolleeRecord`` avec les bornes configurées.
    """
    cfg = cfg or ValidationConfig()
    return create_model(
        "ConfiguredEnrolleeRecord",
        __base__=EnrolleeRecord,
        city_development_index=(
            float,
            Field(ge=cfg.cdi_min, le=cfg.cdi_max, allow_inf_nan=False),
        ),
        training_hours=(int, Field(ge=cfg.training_hours_min, le=cfg.training_hours_max)),
    )


# ---------------------------------------------------------------------------
# Validation d'un DataFrame complet
# ---------------------------------------------------------------------------


class DataValidationError(Exception):
    """Levée quand le jeu de données est globalement inacceptable."""


@dataclass
class ValidationReport:
    """Résumé chiffré d'une validation de DataFrame."""

    total: int
    valid: int
    rejected: int
    errors_by_field: dict[str, int] = field(default_factory=dict)
    errors_by_type: dict[str, int] = field(default_factory=dict)

    @property
    def rejection_rate(self) -> float:
        """Part de lignes rejetées (0 à 1)."""
        return self.rejected / self.total if self.total else 0.0

    def summary(self) -> str:
        """Texte lisible pour les logs et le notebook."""
        lines = [
            f"Lignes totales   : {self.total}",
            f"Lignes valides   : {self.valid}",
            f"Lignes rejetées  : {self.rejected} ({self.rejection_rate:.2%})",
        ]
        if self.errors_by_field:
            lines.append("Erreurs par champ :")
            lines += [f"  - {name}: {count}" for name, count in self.errors_by_field.items()]
        return "\n".join(lines)

    def to_dict(self) -> dict[str, Any]:
        """Version sérialisable (JSON) du rapport."""
        return {
            "total": self.total,
            "valid": self.valid,
            "rejected": self.rejected,
            "rejection_rate": round(self.rejection_rate, 6),
            "errors_by_field": self.errors_by_field,
            "errors_by_type": self.errors_by_type,
        }


def _nan_to_none(record: dict[str, Any]) -> dict[str, Any]:
    """Remplace les valeurs manquantes pandas (NaN, NA, NaT) par ``None``."""
    return {key: (None if _is_missing(value) else value) for key, value in record.items()}


def _is_missing(value: Any) -> bool:
    """Vrai si ``value`` est un scalaire manquant pandas."""
    try:
        return bool(pd.isna(value))
    except (TypeError, ValueError):  # listes, dicts... : pas un scalaire
        return False


def check_columns(df: pd.DataFrame, model: type[BaseModel] = EnrolleeRecord) -> None:
    """Vérifie que les colonnes du DataFrame correspondent au schéma.

    Raises:
        DataValidationError: colonnes obligatoires absentes ou colonnes inconnues.
    """
    expected = set(model.model_fields)
    required = {name for name, info in model.model_fields.items() if info.is_required()}
    present = set(df.columns)
    missing = sorted(required - present)
    unexpected = sorted(present - expected)
    if missing or unexpected:
        raise DataValidationError(
            f"Colonnes invalides — manquantes : {missing} ; inattendues : {unexpected}"
        )


def _format_errors(exc: ValidationError) -> tuple[str, list[str], list[str]]:
    """Extrait (texte, champs en erreur, types d'erreur) d'une ``ValidationError``."""
    fields, types, parts = [], [], []
    for err in exc.errors():
        name = str(err["loc"][0]) if err["loc"] else "__row__"
        fields.append(name)
        types.append(err["type"])
        parts.append(f"{name}: {err['msg']}")
    return " | ".join(parts), fields, types


def validate_dataframe(
    df: pd.DataFrame,
    model: type[BaseModel] = EnrolleeRecord,
    max_rejection_rate: float | None = None,
) -> tuple[pd.DataFrame, pd.DataFrame, ValidationReport]:
    """Valide chaque ligne du DataFrame contre le schéma Pydantic.

    Les lignes valides sont renvoyées **telles quelles** (la validation
    contrôle, elle ne transforme pas). Les lignes invalides sont isolées
    dans un DataFrame « quarantaine » avec la colonne ``validation_errors``.

    Args:
        df: données brutes à contrôler.
        model: schéma à appliquer (``EnrolleeRecord`` ou version configurée).
        max_rejection_rate: si fourni, lève une erreur au-delà de ce taux.

    Returns:
        ``(valid_df, rejected_df, report)``.

    Raises:
        DataValidationError: colonnes incorrectes ou taux de rejet dépassé.
    """
    check_columns(df, model)

    valid_index: list[Any] = []
    rejected_rows: list[dict[str, Any]] = []
    field_counter: Counter[str] = Counter()
    type_counter: Counter[str] = Counter()

    records = df.to_dict(orient="records")
    for index, record in zip(df.index, records, strict=True):
        try:
            model.model_validate(_nan_to_none(record))
        except ValidationError as exc:
            message, fields, types = _format_errors(exc)
            field_counter.update(set(fields))
            type_counter.update(types)
            rejected_rows.append({**record, "validation_errors": message, "_index": index})
        else:
            valid_index.append(index)

    valid_df = df.loc[valid_index].copy()
    if rejected_rows:
        rejected_df = pd.DataFrame(rejected_rows).set_index("_index")
        rejected_df.index.name = df.index.name
    else:
        rejected_df = pd.DataFrame(columns=[*df.columns, "validation_errors"])

    report = ValidationReport(
        total=len(df),
        valid=len(valid_df),
        rejected=len(rejected_df),
        errors_by_field=dict(field_counter.most_common()),
        errors_by_type=dict(type_counter.most_common()),
    )
    logger.info("Validation : %d valides / %d rejetées", report.valid, report.rejected)

    if max_rejection_rate is not None and report.rejection_rate > max_rejection_rate:
        raise DataValidationError(
            f"Taux de rejet {report.rejection_rate:.2%} > seuil {max_rejection_rate:.2%} "
            "— données trop corrompues, arrêt du pipeline."
        )
    return valid_df, rejected_df, report
