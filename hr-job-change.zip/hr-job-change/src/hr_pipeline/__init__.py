"""hr_pipeline : du notebook au code production.

Pipeline de prédiction du changement d'emploi de candidats data scientists
(jeu « HR Analytics : Job Change of Data Scientists »).

Organisation des modules (un module = une responsabilité) :

- ``config``         : chargement/validation de la configuration (YAML + .env)
- ``schemas``        : schémas Pydantic et validation stricte des données
- ``data_loader``    : lecture des fichiers CSV
- ``preprocessing``  : nettoyage et conversion des colonnes textuelles
- ``features``       : ingénierie de variables et ColumnTransformer scikit-learn
- ``model``          : construction, entraînement, sauvegarde du modèle
- ``evaluation``     : métriques et validation croisée
- ``visualization``  : graphiques (matplotlib)
- ``pipeline``       : orchestration de bout en bout
- ``cli``            : interface en ligne de commande
- ``synthetic``      : génération de données de test (valides ou corrompues)
"""

__version__ = "0.1.0"
