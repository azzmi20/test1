"""Orchestration de bout en bout : validation → nettoyage → entraînement → prédiction."""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

import numpy as np
import pandas as pd
from sklearn.pipeline import Pipeline

from hr_pipeline.config import AppConfig
from hr_pipeline.data_loader import (
    load_submission_template,
    load_test,
    load_train,
    save_csv,
)
from hr_pipeline.evaluation import evaluate_classifier
from hr_pipeline.features import model_columns, split_features_target
from hr_pipeline.logging_utils import get_logger
from hr_pipeline.model import (
    get_pipeline_from_config,
    load_model,
    predict_proba,
    save_model,
    split_train_valid,
)
from hr_pipeline.preprocessing import clean_dataframe
from hr_pipeline.schemas import ValidationReport, build_record_model, validate_dataframe

logger = get_logger(__name__)


@dataclass
class TrainingResult:
    """Tout ce que produit un entraînement (pratique pour le notebook)."""

    pipeline: Pipeline
    metrics: dict[str, Any]
    validation_report: ValidationReport
    X_train: pd.DataFrame
    X_valid: pd.DataFrame
    y_train: pd.Series
    y_valid: pd.Series
    proba_valid: np.ndarray


def prepare_dataset(
    raw: pd.DataFrame, config: AppConfig, save_rejected: bool = True
) -> tuple[pd.DataFrame, pd.DataFrame, ValidationReport]:
    """Valide puis nettoie un DataFrame brut.

    Étapes : contrôle du schéma Pydantic (configuré) → mise en quarantaine des
    lignes invalides → conversions déterministes (``clean_dataframe``).

    Args:
        raw: données brutes lues depuis un CSV.
        config: configuration du projet.
        save_rejected: écrit les lignes rejetées dans ``data/processed/``.

    Returns:
        ``(clean_df, rejected_df, report)``.

    Raises:
        DataValidationError: si le taux de rejet dépasse le seuil configuré.
    """
    schema = build_record_model(config.validation)
    valid, rejected, report = validate_dataframe(
        raw, model=schema, max_rejection_rate=config.validation.max_rejection_rate
    )
    if save_rejected and not rejected.empty:
        save_csv(rejected, config.rejected_path, index=True)
    return clean_dataframe(valid), rejected, report


def run_training(
    config: AppConfig, model_name: str | None = None, save: bool = True
) -> TrainingResult:
    """Entraîne le modèle et évalue sur un jeu de validation stratifié.

    Args:
        config: configuration du projet.
        model_name: modèle à entraîner (défaut : celui du YAML).
        save: sauvegarde le modèle et les métriques dans ``models/``.

    Returns:
        Un ``TrainingResult`` complet.
    """
    name = model_name or config.model.name
    raw = load_train(config)
    clean, _, report = prepare_dataset(raw, config)

    X, y = split_features_target(clean, config.features)
    X_train, X_valid, y_train, y_valid = split_train_valid(
        X, y, config.model.test_size, config.project.random_seed
    )

    pipeline = get_pipeline_from_config(config, model_name=name)
    logger.info("Entraînement du modèle '%s' sur %d lignes", name, len(X_train))
    pipeline.fit(X_train, y_train)

    proba = predict_proba(pipeline, X_valid)
    scores = evaluate_classifier(y_valid, proba, config.model.decision_threshold)
    metrics: dict[str, Any] = {
        "model": name,
        "seed": config.project.random_seed,
        "n_train": int(len(X_train)),
        "n_valid": int(len(X_valid)),
        "threshold": config.model.decision_threshold,
        "validation": scores,
        "data_validation": report.to_dict(),
        "feature_columns": model_columns(config.features),
    }
    logger.info("ROC-AUC validation : %.4f", scores["roc_auc"])

    if save:
        save_model(pipeline, config.model_path)
        config.metrics_path.parent.mkdir(parents=True, exist_ok=True)
        config.metrics_path.write_text(json.dumps(metrics, indent=2, ensure_ascii=False), "utf-8")

    return TrainingResult(pipeline, metrics, report, X_train, X_valid, y_train, y_valid, proba)


def run_prediction(config: AppConfig, pipeline: Pipeline | None = None) -> pd.DataFrame:
    """Prédit les probabilités sur le jeu de test et écrit la soumission.

    Le fichier produit a exactement le format de ``sample_submission.csv``
    (mêmes ``enrollee_id``, même ordre). Une ligne de test rejetée par la
    validation reçoit la valeur neutre du modèle de soumission (0.5) plutôt
    qu'une prédiction non fiable.

    Args:
        config: configuration du projet.
        pipeline: modèle déjà chargé (sinon lu depuis ``models/``).

    Returns:
        Le DataFrame de soumission (``enrollee_id``, ``target``).
    """
    model = pipeline or load_model(config.model_path)
    raw = load_test(config)
    clean, rejected, _ = prepare_dataset(raw, config, save_rejected=False)

    probas = pd.Series(predict_proba(model, clean), index=clean["enrollee_id"].to_numpy())
    template = load_submission_template(config)
    submission = template[["enrollee_id"]].copy()
    submission["target"] = submission["enrollee_id"].map(probas)

    n_missing = int(submission["target"].isna().sum())
    if n_missing:
        logger.warning("%d ids sans prédiction fiable : valeur neutre 0.5", n_missing)
    submission["target"] = submission["target"].fillna(0.5).round(6)

    save_csv(submission, config.submission_path)
    return submission
