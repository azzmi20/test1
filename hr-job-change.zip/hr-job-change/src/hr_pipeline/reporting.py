"""Génération de tous les graphiques du rapport en une commande."""

from __future__ import annotations

from pathlib import Path

from hr_pipeline import visualization as viz
from hr_pipeline.config import AppConfig
from hr_pipeline.data_loader import load_train
from hr_pipeline.evaluation import (
    compare_models,
    confusion_counts,
    permutation_importance_table,
    threshold_curve,
)
from hr_pipeline.features import split_features_target
from hr_pipeline.logging_utils import get_logger
from hr_pipeline.pipeline import prepare_dataset, run_training
from hr_pipeline.schemas import build_record_model, validate_dataframe
from hr_pipeline.synthetic import corrupt_dataframe

logger = get_logger(__name__)

CATEGORY_COLUMNS_FOR_RATES: list[str] = [
    "relevent_experience",
    "enrolled_university",
    "education_level",
    "company_size",
]

CORRELATION_COLUMNS: list[str] = [
    "city_development_index",
    "training_hours",
    "experience_years",
    "last_new_job_years",
    "company_size_rank",
    "education_rank",
    "n_missing",
    "is_full_time_student",
]


def generate_all_figures(config: AppConfig) -> list[Path]:
    """Produit les 12 figures du rapport dans ``reports/figures/``.

    Args:
        config: configuration du projet.

    Returns:
        La liste des chemins de fichiers écrits.
    """
    viz.plt.switch_backend("Agg")  # génération sans écran (serveur, CI)
    out = config.figures_path
    target = config.features.target
    raw = load_train(config)
    clean, _, _ = prepare_dataset(raw, config, save_rejected=False)
    paths: list[Path] = []

    def _save(name: str, fig_fn, *args, **kwargs) -> None:  # type: ignore[no-untyped-def]
        path = out / name
        fig = fig_fn(*args, save_to=path, **kwargs)
        viz.plt.close(fig)
        paths.append(path)
        logger.info("Figure : %s", path.name)

    # --- Exploration --------------------------------------------------------
    _save("01_target_distribution.png", viz.plot_target_distribution, raw, target)
    _save("02_missing_values.png", viz.plot_missing_values, raw.drop(columns=[target]))
    _save("03_numeric_by_target.png", viz.plot_numeric_by_target, raw, target=target)
    _save(
        "04_rate_by_category.png",
        viz.plot_rate_by_category,
        raw,
        CATEGORY_COLUMNS_FOR_RATES,
        target,
    )
    _save("05_rate_by_cdi.png", viz.plot_rate_by_cdi, raw, target)
    _save("06_correlation.png", viz.plot_correlation, clean, CORRELATION_COLUMNS, target)

    # --- Modélisation -------------------------------------------------------
    X, y = split_features_target(clean, config.features)
    cv_table = compare_models(config, X, y)
    _save("07_model_comparison.png", viz.plot_model_comparison, cv_table)

    result = run_training(config, save=False)
    cm = confusion_counts(result.y_valid, result.proba_valid, config.model.decision_threshold)
    importance = permutation_importance_table(
        result.pipeline, result.X_valid, result.y_valid, config
    )
    curve = threshold_curve(result.y_valid, result.proba_valid)

    _save("08_roc_pr.png", viz.plot_roc_pr, result.y_valid, result.proba_valid)
    _save("09_confusion_matrix.png", viz.plot_confusion, cm, config.model.decision_threshold)
    _save("10_feature_importance.png", viz.plot_feature_importance, importance)
    _save(
        "11_threshold_tradeoff.png",
        viz.plot_threshold_tradeoff,
        curve,
        config.model.decision_threshold,
    )

    # --- Démonstration de la validation Pydantic ----------------------------
    corrupted, _ = corrupt_dataframe(raw.drop(columns=[target]), rate=0.1, seed=7)
    _, _, report = validate_dataframe(corrupted, build_record_model(config.validation))
    _save("12_validation_report.png", viz.plot_validation_report, report)
    return paths
