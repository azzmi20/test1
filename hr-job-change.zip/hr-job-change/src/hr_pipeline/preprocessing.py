"""Nettoyage *sans état* : conversion des colonnes textuelles en nombres.

« Sans état » signifie que ces transformations ne dépendent d'aucune
statistique apprise sur les données (pas de moyenne, pas de médiane) : elles
appliquent des règles fixes (``"<1"`` → 0.5 an). On peut donc les appliquer
sans risque de fuite de données (*data leakage*) avant le découpage
train/test. Les opérations qui apprennent des statistiques (imputation,
standardisation) sont dans ``features.py`` à l'intérieur du pipeline scikit-learn.
"""

from __future__ import annotations

import pandas as pd

# Ordres naturels des modalités ordinales -----------------------------------
EDUCATION_RANK: dict[str, int] = {
    "Primary School": 0,
    "High School": 1,
    "Graduate": 2,
    "Masters": 3,
    "Phd": 4,
}

COMPANY_SIZE_RANK: dict[str, int] = {
    "<10": 1,
    "10/49": 2,
    "50-99": 3,
    "100-500": 4,
    "500-999": 5,
    "1000-4999": 6,
    "5000-9999": 7,
    "10000+": 8,
}

# Colonnes brutes dont on compte les valeurs manquantes (variable n_missing)
RAW_OPTIONAL_COLUMNS: list[str] = [
    "gender",
    "enrolled_university",
    "education_level",
    "major_discipline",
    "experience",
    "company_size",
    "company_type",
    "last_new_job",
]


def parse_experience(series: pd.Series) -> pd.Series:
    """Convertit la colonne ``experience`` en années (float).

    Règles : ``"<1"`` → 0.5 ; ``">20"`` → 21 ; ``"7"`` → 7.0 ; manquant → NaN.

    Args:
        series: colonne texte brute.

    Returns:
        Série de flottants, NaN pour les valeurs manquantes ou illisibles.
    """
    cleaned = series.astype("object").replace({"<1": "0.5", ">20": "21"})
    return pd.to_numeric(cleaned, errors="coerce").astype("float64")


def parse_last_new_job(series: pd.Series) -> pd.Series:
    """Convertit ``last_new_job`` (années depuis le dernier changement) en float.

    Règles : ``"never"`` → 0 ; ``">4"`` → 5 ; ``"2"`` → 2.0 ; manquant → NaN.
    """
    cleaned = series.astype("object").replace({"never": "0", ">4": "5"})
    return pd.to_numeric(cleaned, errors="coerce").astype("float64")


def rank_company_size(series: pd.Series) -> pd.Series:
    """Encode la taille d'entreprise en rang ordinal de 1 (<10) à 8 (10000+)."""
    return series.astype("object").map(COMPANY_SIZE_RANK).astype("float64")


def rank_education(series: pd.Series) -> pd.Series:
    """Encode le niveau d'études en rang ordinal de 0 (primaire) à 4 (doctorat)."""
    return series.astype("object").map(EDUCATION_RANK).astype("float64")


def count_missing(df: pd.DataFrame, columns: list[str] | None = None) -> pd.Series:
    """Compte, pour chaque ligne, le nombre de colonnes optionnelles manquantes."""
    cols = [c for c in (columns or RAW_OPTIONAL_COLUMNS) if c in df.columns]
    return df[cols].isna().sum(axis=1).astype("int64")


def clean_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    """Applique toutes les conversions déterministes et ajoute les variables dérivées.

    La fonction travaille sur une **copie** : le DataFrame d'entrée n'est jamais
    modifié (contrairement aux notebooks où ``df`` est muté de cellule en cellule).

    Colonnes ajoutées :
        ``experience_years``, ``last_new_job_years``, ``company_size_rank``,
        ``education_rank``, ``company_size_missing``, ``company_type_missing``,
        ``is_full_time_student``, ``n_missing``.

    Args:
        df: données brutes (validées ou non).

    Returns:
        Un nouveau DataFrame enrichi.
    """
    out = df.copy()
    out["experience_years"] = parse_experience(out["experience"])
    out["last_new_job_years"] = parse_last_new_job(out["last_new_job"])
    out["company_size_rank"] = rank_company_size(out["company_size"])
    out["education_rank"] = rank_education(out["education_level"])
    out["company_size_missing"] = out["company_size"].isna().astype("int64")
    out["company_type_missing"] = out["company_type"].isna().astype("int64")
    out["is_full_time_student"] = (out["enrolled_university"] == "Full time course").astype("int64")
    out["n_missing"] = count_missing(out)
    return out
