"""Configuration centralisée des logs (remplace les ``print`` des notebooks)."""

from __future__ import annotations

import logging

LOG_FORMAT = "%(asctime)s | %(levelname)-7s | %(name)s | %(message)s"


def setup_logging(level: str = "INFO") -> None:
    """Configure le logging racine une seule fois.

    Args:
        level: niveau minimal affiché (``DEBUG``, ``INFO``, ``WARNING``, ``ERROR``).
    """
    root = logging.getLogger()
    if not root.handlers:
        logging.basicConfig(format=LOG_FORMAT, datefmt="%H:%M:%S")
    root.setLevel(getattr(logging, level.upper(), logging.INFO))


def get_logger(name: str) -> logging.Logger:
    """Renvoie un logger nommé (convention : ``get_logger(__name__)``)."""
    return logging.getLogger(name)
