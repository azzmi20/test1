"""Construction du pré-processeur scikit-learn (partie *avec état*).

Tout ce qui apprend une statistique sur les données (médiane pour imputer,
moyenne/écart-type pour standardiser, catégories pour l'encodage one-hot) est
placé dans un ``ColumnTransformer`` **à l'intérieur** du ``Pipeline`` : il est
ajusté uniquement sur le jeu d'entraînement, y compris à chaque pli de la
validation croisée. C'est la garantie anti-fuite de données.
"""

from __future__ import annotations

import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from hr_pipeline.config import FeaturesConfig

UNKNOWN_LABEL = "Unknown"


def split_features_target(df: pd.DataFrame, cfg: FeaturesConfig) -> tuple[pd.DataFrame, pd.Series]:
    """Sépare la matrice de variables ``X`` de la cible ``y``.

    Args:
        df: DataFrame nettoyé contenant la colonne cible.
        cfg: description des colonnes.

    Returns:
        ``(X, y)`` avec ``y`` converti en entiers 0/1.

    Raises:
        KeyError: si la colonne cible est absente.
    """
    if cfg.target not in df.columns:
        raise KeyError(f"Colonne cible '{cfg.target}' absente du DataFrame")
    y = df[cfg.target].astype(int)
    X = df.drop(columns=[cfg.target])
    return X, y


def model_columns(cfg: FeaturesConfig) -> list[str]:
    """Liste ordonnée des colonnes réellement consommées par le modèle."""
    return [*cfg.numeric, *cfg.categorical, *cfg.binary_flags]


def build_preprocessor(cfg: FeaturesConfig) -> ColumnTransformer:
    """Construit le ``ColumnTransformer`` du projet.

    - numériques : imputation par la médiane puis standardisation ;
    - ville (haute cardinalité) : « Unknown » + one-hot, villes rares regroupées ;
    - autres catégorielles : « Unknown » + one-hot ;
    - indicateurs binaires : conservés tels quels.

    Les valeurs manquantes des catégorielles sont explicitement codées
    « Unknown » car, dans ce jeu de données, **l'absence d'information est
    elle-même informative** (cf. graphique du taux de départ).

    Args:
        cfg: description des colonnes (listes issues du YAML).

    Returns:
        Un ``ColumnTransformer`` non ajusté.
    """
    numeric = Pipeline(
        [
            ("impute", SimpleImputer(strategy="median")),
            ("scale", StandardScaler()),
        ]
    )

    def _categorical(min_frequency: int | None) -> Pipeline:
        return Pipeline(
            [
                ("impute", SimpleImputer(strategy="constant", fill_value=UNKNOWN_LABEL)),
                (
                    "onehot",
                    OneHotEncoder(
                        handle_unknown="infrequent_if_exist",
                        min_frequency=min_frequency,
                        sparse_output=False,
                    ),
                ),
            ]
        )

    other_categorical = [c for c in cfg.categorical if c != "city"]
    transformers: list[tuple[str, object, list[str]]] = [("num", numeric, cfg.numeric)]
    if "city" in cfg.categorical:
        transformers.append(("city", _categorical(cfg.city_min_frequency), ["city"]))
    if other_categorical:
        transformers.append(("cat", _categorical(None), other_categorical))
    if cfg.binary_flags:
        transformers.append(("flags", "passthrough", cfg.binary_flags))

    return ColumnTransformer(transformers, remainder="drop", verbose_feature_names_out=False)
