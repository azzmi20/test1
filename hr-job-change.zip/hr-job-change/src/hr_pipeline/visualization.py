"""Graphiques du projet (matplotlib).

Conventions de lecture (palette catégorielle validée pour le daltonisme) :

- **bleu** = reste en poste (classe 0), **orange** = cherche à partir (classe 1) ;
- une seule teinte (bleu clair → foncé) pour les magnitudes (matrices, comptages) ;
- deux teintes + gris neutre pour les écarts de signe (corrélations) ;
- grille discrète, pas de double axe, valeurs écrites directement sur les barres.

Chaque fonction ``plot_*`` **renvoie** la ``Figure`` (affichable dans un
notebook) et l'enregistre si ``save_to`` est fourni.
"""

from __future__ import annotations

from collections.abc import Sequence
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.figure import Figure
from sklearn.metrics import precision_recall_curve, roc_auc_score, roc_curve

from hr_pipeline.schemas import ValidationReport

# --- Palette -----------------------------------------------------------------
SURFACE = "#fcfcfb"
INK = "#0b0b0b"
INK_2 = "#52514e"
GRID = "#e6e5e1"
STAY = "#2a78d6"  # classe 0 : reste en poste
LEAVE = "#eb6834"  # classe 1 : cherche à partir
NEUTRAL = "#8a8984"
AQUA = "#1baf7a"

SEQUENTIAL = LinearSegmentedColormap.from_list("seq_blue", ["#eaf2fc", "#8db8ec", "#0d3f80"])
DIVERGING = LinearSegmentedColormap.from_list("div_blue_orange", [STAY, "#f0efec", LEAVE])


def apply_style() -> None:
    """Applique le style graphique commun (appelé automatiquement)."""
    plt.rcParams.update(
        {
            "figure.facecolor": SURFACE,
            "axes.facecolor": SURFACE,
            "savefig.facecolor": SURFACE,
            "axes.edgecolor": GRID,
            "axes.labelcolor": INK_2,
            "axes.titlecolor": INK,
            "axes.titleweight": "bold",
            "axes.titlesize": 12,
            "axes.titlelocation": "left",
            "axes.spines.top": False,
            "axes.spines.right": False,
            "axes.grid": True,
            "grid.color": GRID,
            "grid.linewidth": 0.8,
            "axes.axisbelow": True,
            "xtick.color": INK_2,
            "ytick.color": INK_2,
            "text.color": INK,
            "font.size": 10,
            "legend.frameon": False,
            "lines.linewidth": 2,
        }
    )


apply_style()


def save_figure(fig: Figure, path: str | Path, dpi: int = 150) -> Path:
    """Enregistre une figure en créant le dossier si besoin."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=dpi, bbox_inches="tight")
    return path


def _finish(fig: Figure, save_to: str | Path | None) -> Figure:
    """Ajuste la mise en page et enregistre si demandé."""
    fig.tight_layout()
    if save_to is not None:
        save_figure(fig, save_to)
    return fig


def _clean_axes(ax: plt.Axes, grid_axis: str = "y") -> None:
    """Garde uniquement la grille utile (discrète)."""
    ax.grid(False)
    ax.grid(True, axis=grid_axis)


# ---------------------------------------------------------------------------
# Exploration
# ---------------------------------------------------------------------------


def plot_target_distribution(
    df: pd.DataFrame, target: str = "target", save_to: str | Path | None = None
) -> Figure:
    """Barres : effectif et part des deux classes (déséquilibre de la cible)."""
    counts = df[target].value_counts().reindex([0, 1])
    share = counts / counts.sum()
    fig, ax = plt.subplots(figsize=(6, 4))
    bars = ax.bar(
        ["Reste en poste (0)", "Cherche à partir (1)"],
        counts.to_numpy(),
        color=[STAY, LEAVE],
        width=0.55,
    )
    for bar, n, s in zip(bars, counts, share, strict=True):
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height(),
            f"{n:,}\n{s:.1%}".replace(",", " "),
            ha="center",
            va="bottom",
            color=INK,
            fontsize=10,
        )
    ax.set_ylim(0, counts.max() * 1.18)
    ax.set_ylabel("Candidats")
    ax.set_title("Cible déséquilibrée : 1 candidat sur 4 cherche à partir")
    _clean_axes(ax)
    return _finish(fig, save_to)


def plot_missing_values(df: pd.DataFrame, save_to: str | Path | None = None) -> Figure:
    """Barres horizontales : pourcentage de valeurs manquantes par colonne."""
    pct = (df.isna().mean() * 100).sort_values()
    pct = pct[pct > 0]
    fig, ax = plt.subplots(figsize=(7, 0.45 * max(len(pct), 3) + 1.2))
    bars = ax.barh(pct.index, pct.to_numpy(), color=STAY, height=0.6)
    for bar, value in zip(bars, pct, strict=True):
        ax.text(value + 0.6, bar.get_y() + bar.get_height() / 2, f"{value:.1f} %", va="center")
    ax.set_xlim(0, max(pct.max() * 1.15, 5))
    ax.set_xlabel("Valeurs manquantes (%)")
    ax.set_title("Où manque l'information ?")
    _clean_axes(ax, "x")
    return _finish(fig, save_to)


def plot_numeric_by_target(
    df: pd.DataFrame,
    columns: Sequence[str] = ("city_development_index", "training_hours"),
    target: str = "target",
    save_to: str | Path | None = None,
) -> Figure:
    """Histogrammes normalisés par classe (une case par variable numérique)."""
    fig, axes = plt.subplots(1, len(columns), figsize=(5.2 * len(columns), 4))
    axes = np.atleast_1d(axes)
    for ax, col in zip(axes, columns, strict=True):
        lo, hi = df[col].min(), df[col].quantile(0.995)
        bins = np.linspace(lo, hi, 30)
        for cls, color, label in ((0, STAY, "Reste"), (1, LEAVE, "Part")):
            values = df.loc[df[target] == cls, col].clip(upper=hi)
            ax.hist(
                values,
                bins=bins,
                density=True,
                alpha=0.55,
                color=color,
                label=label,
                edgecolor=SURFACE,
                linewidth=1,
            )
        ax.set_xlabel(col)
        ax.set_ylabel("Densité")
        ax.set_title(f"Distribution de {col}")
        _clean_axes(ax)
    axes[0].legend(title="Classe", loc="upper left")
    return _finish(fig, save_to)


def plot_rate_by_category(
    df: pd.DataFrame,
    columns: Sequence[str],
    target: str = "target",
    save_to: str | Path | None = None,
) -> Figure:
    """Taux de départ par modalité (petits multiples), avec la moyenne globale en repère."""
    overall = float(df[target].mean())
    n = len(columns)
    ncols = 2
    nrows = int(np.ceil(n / ncols))
    fig, axes = plt.subplots(nrows, ncols, figsize=(11, 3.2 * nrows))
    axes_flat = np.atleast_1d(axes).ravel()
    for ax, col in zip(axes_flat, columns, strict=False):
        grouped = (
            df.assign(_cat=df[col].astype("object").fillna("Unknown"))
            .groupby("_cat")[target]
            .agg(["mean", "size"])
            .sort_values("mean")
        )
        grouped = grouped[grouped["size"] >= 30]
        colors = [LEAVE if m > overall else STAY for m in grouped["mean"]]
        bars = ax.barh(grouped.index, grouped["mean"] * 100, color=colors, height=0.62)
        ax.axvline(overall * 100, color=INK_2, linewidth=1.2, linestyle=(0, (4, 3)))
        for bar, (rate, size) in zip(
            bars, zip(grouped["mean"], grouped["size"], strict=True), strict=True
        ):
            ax.text(
                rate * 100 + 0.8,
                bar.get_y() + bar.get_height() / 2,
                f"{rate:.0%}  (n={size})",
                va="center",
                fontsize=8.5,
                color=INK_2,
                # fond = surface : le trait pointillé ne traverse pas le texte
                bbox={"facecolor": SURFACE, "edgecolor": "none", "pad": 1.5},
                zorder=5,
            )
        ax.set_xlim(0, max(grouped["mean"].max() * 100 * 1.35, overall * 100 * 1.5))
        ax.set_title(col)
        ax.set_xlabel("Taux de départ (%)")
        _clean_axes(ax, "x")
    for ax in axes_flat[n:]:
        ax.set_visible(False)
    fig.suptitle(
        f"Taux de départ par modalité (trait pointillé : moyenne {overall:.0%}) "
        "— orange : au-dessus, bleu : en dessous",
        x=0.01,
        ha="left",
        fontsize=12,
        fontweight="bold",
    )
    fig.tight_layout(rect=(0, 0, 1, 0.96))
    if save_to is not None:
        save_figure(fig, save_to)
    return fig


def plot_rate_by_cdi(
    df: pd.DataFrame,
    target: str = "target",
    bins: int = 10,
    save_to: str | Path | None = None,
) -> Figure:
    """Taux de départ par tranche d'indice de développement de la ville."""
    cut = pd.qcut(df["city_development_index"], q=bins, duplicates="drop")
    grouped = df.groupby(cut, observed=True)[target].agg(["mean", "size"])
    labels = [f"{iv.left:.2f}–{iv.right:.2f}" for iv in grouped.index]
    fig, ax = plt.subplots(figsize=(9, 4.2))
    bars = ax.bar(labels, grouped["mean"] * 100, color=STAY, width=0.65)
    for bar, value in zip(bars, grouped["mean"], strict=True):
        ax.text(bar.get_x() + bar.get_width() / 2, value * 100 + 0.6, f"{value:.0%}", ha="center")
    ax.axhline(df[target].mean() * 100, color=INK_2, linewidth=1.2, linestyle=(0, (4, 3)))
    ax.set_ylabel("Taux de départ (%)")
    ax.set_xlabel("Tranche (déciles) de city_development_index")
    ax.set_title("Plus la ville est peu développée, plus on cherche à partir")
    plt.setp(ax.get_xticklabels(), rotation=30, ha="right")
    _clean_axes(ax)
    return _finish(fig, save_to)


def plot_correlation(
    df: pd.DataFrame,
    columns: Sequence[str],
    target: str = "target",
    save_to: str | Path | None = None,
) -> Figure:
    """Matrice de corrélation (divergente bleu ↔ orange, gris au centre)."""
    cols = [*columns, target]
    corr = df[cols].corr()
    fig, ax = plt.subplots(figsize=(8, 6.5))
    im = ax.imshow(corr.to_numpy(), cmap=DIVERGING, vmin=-1, vmax=1)
    ax.set_xticks(range(len(cols)), labels=cols, rotation=40, ha="right")
    ax.set_yticks(range(len(cols)), labels=cols)
    ax.grid(False)
    for i in range(len(cols)):
        for j in range(len(cols)):
            value = corr.iat[i, j]
            ax.text(
                j,
                i,
                f"{value:.2f}",
                ha="center",
                va="center",
                fontsize=8,
                color=INK,
            )
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.03, label="Corrélation de Pearson")
    ax.set_title("Corrélations entre variables numériques et la cible")
    return _finish(fig, save_to)


# ---------------------------------------------------------------------------
# Modélisation
# ---------------------------------------------------------------------------


def plot_model_comparison(cv_table: pd.DataFrame, save_to: str | Path | None = None) -> Figure:
    """ROC-AUC moyen (± écart-type) de chaque modèle en validation croisée."""
    table = cv_table.sort_values("roc_auc_mean")
    fig, ax = plt.subplots(figsize=(7.5, 3.6))
    y = np.arange(len(table))
    ax.errorbar(
        table["roc_auc_mean"],
        y,
        xerr=table["roc_auc_std"],
        fmt="o",
        color=STAY,
        ecolor=STAY,
        elinewidth=2,
        capsize=4,
        markersize=9,
        markeredgecolor=SURFACE,
        markeredgewidth=2,
    )
    for yi, mean in zip(y, table["roc_auc_mean"], strict=True):
        ax.text(mean, yi + 0.22, f"{mean:.3f}", ha="center", fontsize=9.5, color=INK)
    ax.set_yticks(y, labels=table["model"])
    ax.set_ylim(-0.6, len(table) - 0.3)
    # axe volontairement large : évite d'exagérer des écarts de quelques millièmes
    ax.set_xlim(table["roc_auc_mean"].min() - 0.05, table["roc_auc_mean"].max() + 0.05)
    ax.set_xlabel("ROC-AUC moyen en validation croisée (± écart-type)")
    ax.set_title("Comparaison des modèles")
    _clean_axes(ax, "x")
    return _finish(fig, save_to)


def plot_roc_pr(
    y_true: pd.Series | np.ndarray,
    y_proba: np.ndarray,
    save_to: str | Path | None = None,
) -> Figure:
    """Courbes ROC et précision-rappel côte à côte."""
    fpr, tpr, _ = roc_curve(y_true, y_proba)
    precision, recall, _ = precision_recall_curve(y_true, y_proba)
    auc = roc_auc_score(y_true, y_proba)
    base = float(np.mean(y_true))

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 4.4))
    ax1.plot(fpr, tpr, color=STAY)
    ax1.plot([0, 1], [0, 1], color=NEUTRAL, linestyle=(0, (4, 3)), linewidth=1.2)
    ax1.text(0.55, 0.25, f"AUC = {auc:.3f}", color=STAY, fontsize=11, fontweight="bold")
    ax1.set_xlabel("Taux de faux positifs")
    ax1.set_ylabel("Taux de vrais positifs (rappel)")
    ax1.set_title("Courbe ROC")
    ax1.set_aspect("equal", adjustable="box")

    keep = recall > 0.01  # les tout premiers points (1 seul candidat) sont instables
    ax2.plot(recall[keep], precision[keep], color=LEAVE)
    ax2.axhline(base, color=NEUTRAL, linestyle=(0, (4, 3)), linewidth=1.2)
    ax2.text(0.02, base + 0.02, f"hasard = {base:.2f}", color=INK_2, fontsize=9)
    ax2.set_xlabel("Rappel")
    ax2.set_ylabel("Précision")
    ax2.set_title("Courbe précision-rappel")
    ax2.set_ylim(0, 1.02)
    return _finish(fig, save_to)


def plot_confusion(
    cm: np.ndarray, threshold: float = 0.5, save_to: str | Path | None = None
) -> Figure:
    """Matrice de confusion : effectifs et part par classe réelle."""
    norm = cm / cm.sum(axis=1, keepdims=True)
    fig, ax = plt.subplots(figsize=(5.4, 4.6))
    ax.imshow(norm, cmap=SEQUENTIAL, vmin=0, vmax=1)
    labels = ["Reste (0)", "Part (1)"]
    ax.set_xticks([0, 1], labels=labels)
    ax.set_yticks([0, 1], labels=labels)
    ax.set_xlabel("Classe prédite")
    ax.set_ylabel("Classe réelle")
    ax.grid(False)
    for i in range(2):
        for j in range(2):
            ax.text(
                j,
                i,
                f"{cm[i, j]}\n({norm[i, j]:.0%})",
                ha="center",
                va="center",
                color="white" if norm[i, j] > 0.5 else INK,
                fontsize=12,
            )
    ax.set_title(f"Matrice de confusion (seuil {threshold:.2f})")
    return _finish(fig, save_to)


def plot_feature_importance(
    table: pd.DataFrame, top: int = 12, save_to: str | Path | None = None
) -> Figure:
    """Importance par permutation (perte de ROC-AUC), top-N variables."""
    top_table = table.head(top).iloc[::-1]
    fig, ax = plt.subplots(figsize=(7.5, 0.42 * len(top_table) + 1.4))
    bars = ax.barh(
        top_table["feature"],
        top_table["importance_mean"],
        xerr=top_table["importance_std"],
        color=STAY,
        height=0.62,
        error_kw={"ecolor": INK_2, "elinewidth": 1.2, "capsize": 3},
    )
    for bar, value in zip(bars, top_table["importance_mean"], strict=True):
        ax.text(
            max(value, 0) + top_table["importance_mean"].max() * 0.04,
            bar.get_y() + bar.get_height() / 2,
            f"{value:.3f}",
            va="center",
            fontsize=9,
        )
    ax.set_xlabel("Perte de ROC-AUC quand la variable est mélangée")
    ax.set_title("Variables les plus utilisées par le modèle")
    _clean_axes(ax, "x")
    return _finish(fig, save_to)


def plot_threshold_tradeoff(
    curve: pd.DataFrame, chosen: float = 0.5, save_to: str | Path | None = None
) -> Figure:
    """Précision, rappel et F1 selon le seuil de décision."""
    fig, ax = plt.subplots(figsize=(8, 4.4))
    styles = {"precision": (STAY, "Précision"), "recall": (LEAVE, "Rappel"), "f1": (AQUA, "F1")}
    for column, (color, label) in styles.items():
        ax.plot(curve["threshold"], curve[column], color=color, label=label)
    ax.axvline(chosen, color=INK_2, linewidth=1.2, linestyle=(0, (4, 3)))
    ax.text(chosen + 0.01, 0.04, f"seuil = {chosen:.2f}", color=INK_2, fontsize=9)
    ax.set_xlim(0.05, curve["threshold"].max())
    ax.set_ylim(0, 1.02)
    ax.set_xlabel("Seuil de décision")
    ax.set_ylabel("Score")
    ax.set_title("Compromis précision / rappel selon le seuil")
    ax.legend(loc="lower left", ncols=3)
    _clean_axes(ax, "y")
    return _finish(fig, save_to)


# ---------------------------------------------------------------------------
# Validation Pydantic
# ---------------------------------------------------------------------------


def plot_validation_report(
    report: ValidationReport, title: str | None = None, save_to: str | Path | None = None
) -> Figure:
    """Nombre de lignes rejetées par champ fautif (démonstration du schéma)."""
    items = sorted(report.errors_by_field.items(), key=lambda kv: kv[1])
    fig, ax = plt.subplots(figsize=(7.5, 0.5 * max(len(items), 3) + 1.5))
    if items:
        names, counts = zip(*items, strict=True)
        bars = ax.barh(names, counts, color=LEAVE, height=0.6)
        for bar, value in zip(bars, counts, strict=True):
            ax.text(
                value + max(counts) * 0.02,
                bar.get_y() + bar.get_height() / 2,
                str(value),
                va="center",
            )
        ax.set_xlim(0, max(counts) * 1.15)
    ax.set_xlabel("Lignes rejetées")
    ax.set_title(
        title
        or f"Lignes rejetées par champ — {report.rejected}/{report.total} "
        f"({report.rejection_rate:.1%})"
    )
    _clean_axes(ax, "x")
    return _finish(fig, save_to)
