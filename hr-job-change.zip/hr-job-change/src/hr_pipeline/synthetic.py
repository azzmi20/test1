"""Données synthétiques : valides (pour les tests) ou volontairement corrompues.

Utilité pédagogique : démontrer que le schéma Pydantic détecte bien les
corruptions, et tester le pipeline sans dépendre des vrais fichiers.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from hr_pipeline.schemas import (
    CompanySize,
    CompanyType,
    EducationLevel,
    EnrolledUniversity,
    Gender,
    MajorDiscipline,
    RelevantExperience,
)

# Types de corruption injectés (nom -> description)
CORRUPTION_KINDS: dict[str, str] = {
    "cdi_out_of_range": "city_development_index > 1 (ex. 1.7)",
    "cdi_negative": "city_development_index négatif",
    "hours_negative": "training_hours négatif",
    "hours_text": "training_hours non numérique (« abc »)",
    "bad_gender": "gender hors modalités (« Unknown? »)",
    "bad_experience": "experience hors modalités (« 99 »)",
    "bad_city": "city mal formée (« Paris »)",
    "bad_id": "enrollee_id <= 0",
}


def _choice(rng: np.random.Generator, values: list[str], n: int, p_missing: float) -> list[object]:
    """Tire ``n`` modalités, avec une proportion ``p_missing`` de valeurs manquantes."""
    drawn: list[object] = list(rng.choice(values, size=n))
    mask = rng.random(n) < p_missing
    return [None if m else v for v, m in zip(drawn, mask, strict=True)]


def make_synthetic_df(n: int = 500, seed: int = 0, with_target: bool = True) -> pd.DataFrame:
    """Génère ``n`` lignes **valides** vis-à-vis du schéma.

    La cible dépend (légèrement) de l'indice de développement de la ville et de
    l'expérience, pour que les modèles aient un signal à apprendre dans les tests.

    Args:
        n: nombre de lignes.
        seed: graine aléatoire.
        with_target: ajoute la colonne ``target`` (absente du jeu de test réel).
    """
    rng = np.random.default_rng(seed)
    cdi = np.round(rng.uniform(0.45, 0.95, n), 3)
    experience = rng.choice(["<1", *[str(i) for i in range(1, 21)], ">20"], size=n)
    df = pd.DataFrame(
        {
            "enrollee_id": np.arange(1, n + 1),
            "city": [f"city_{i}" for i in rng.integers(1, 15, n)],
            "city_development_index": cdi,
            "gender": _choice(rng, [g.value for g in Gender], n, 0.2),
            "relevent_experience": rng.choice([r.value for r in RelevantExperience], size=n),
            "enrolled_university": _choice(rng, [e.value for e in EnrolledUniversity], n, 0.02),
            "education_level": _choice(rng, [e.value for e in EducationLevel], n, 0.02),
            "major_discipline": _choice(rng, [m.value for m in MajorDiscipline], n, 0.15),
            "experience": experience,
            "company_size": _choice(rng, [c.value for c in CompanySize], n, 0.3),
            "company_type": _choice(rng, [c.value for c in CompanyType], n, 0.3),
            "last_new_job": _choice(rng, ["never", "1", "2", "3", "4", ">4"], n, 0.02),
            "training_hours": rng.integers(1, 300, n),
        }
    )
    if with_target:
        score = -9.0 * (cdi - 0.7) + 1.5 * df["company_size"].isna().to_numpy() - 0.8
        prob = 1.0 / (1.0 + np.exp(-score))
        df["target"] = (rng.random(n) < prob).astype(int)
    return df


def corrupt_dataframe(
    df: pd.DataFrame, rate: float = 0.1, seed: int = 0
) -> tuple[pd.DataFrame, dict[int, str]]:
    """Corrompt volontairement une fraction des lignes.

    Chaque ligne choisie reçoit **une** corruption garantie invalide.

    Args:
        df: DataFrame valide (n'est pas modifié).
        rate: part de lignes à corrompre (0 à 1).
        seed: graine aléatoire.

    Returns:
        ``(df_corrompu, corruptions)`` où ``corruptions`` associe l'index de
        chaque ligne corrompue au type de corruption appliqué.
    """
    rng = np.random.default_rng(seed)
    out = df.copy()
    # colonnes qui peuvent recevoir du texte : on les passe en ``object``
    for col in ("training_hours", "city_development_index", "enrollee_id"):
        out[col] = out[col].astype(object)

    n_bad = max(1, int(len(out) * rate))
    chosen = rng.choice(out.index.to_numpy(), size=n_bad, replace=False)
    kinds = list(CORRUPTION_KINDS)
    corruptions: dict[int, str] = {}

    for idx in chosen:
        kind = kinds[int(rng.integers(len(kinds)))]
        if kind == "cdi_out_of_range":
            out.at[idx, "city_development_index"] = 1.7
        elif kind == "cdi_negative":
            out.at[idx, "city_development_index"] = -0.3
        elif kind == "hours_negative":
            out.at[idx, "training_hours"] = -12
        elif kind == "hours_text":
            out.at[idx, "training_hours"] = "abc"
        elif kind == "bad_gender":
            out.at[idx, "gender"] = "Unknown?"
        elif kind == "bad_experience":
            out.at[idx, "experience"] = "99"
        elif kind == "bad_city":
            out.at[idx, "city"] = "Paris"
        elif kind == "bad_id":
            out.at[idx, "enrollee_id"] = 0
        corruptions[int(idx)] = kind
    return out, corruptions
