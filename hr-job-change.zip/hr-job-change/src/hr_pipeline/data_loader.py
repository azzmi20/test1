"""Lecture des fichiers de données (aucune transformation ici)."""

from __future__ import annotations

from pathlib import Path

import pandas as pd

from hr_pipeline.config import AppConfig
from hr_pipeline.logging_utils import get_logger

logger = get_logger(__name__)


def read_csv(path: str | Path) -> pd.DataFrame:
    """Lit un CSV en vérifiant que le fichier existe et n'est pas vide.

    Args:
        path: chemin du fichier CSV.

    Returns:
        Le DataFrame brut.

    Raises:
        FileNotFoundError: fichier absent.
        ValueError: fichier sans aucune ligne.
    """
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Fichier de données introuvable : {path}")
    df = pd.read_csv(path)
    if df.empty:
        raise ValueError(f"Le fichier {path} ne contient aucune ligne")
    logger.info("Lu %s : %d lignes, %d colonnes", path.name, *df.shape)
    return df


def load_train(config: AppConfig) -> pd.DataFrame:
    """Charge le jeu d'entraînement défini dans la configuration."""
    return read_csv(config.train_path)


def load_test(config: AppConfig) -> pd.DataFrame:
    """Charge le jeu de test (sans la colonne ``target``)."""
    return read_csv(config.test_path)


def load_submission_template(config: AppConfig) -> pd.DataFrame:
    """Charge le modèle de fichier de soumission (``enrollee_id``, ``target``)."""
    return read_csv(config.template_path)


def save_csv(df: pd.DataFrame, path: str | Path, index: bool = False) -> Path:
    """Écrit un CSV en créant les dossiers parents si besoin.

    Returns:
        Le chemin écrit (pratique pour les logs).
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=index)
    logger.info("Écrit %s (%d lignes)", path, len(df))
    return path
