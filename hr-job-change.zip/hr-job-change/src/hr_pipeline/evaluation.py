"""Métriques, comparaison de modèles et importance des variables."""

from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.inspection import permutation_importance
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.model_selection import StratifiedKFold, cross_validate
from sklearn.pipeline import Pipeline

from hr_pipeline.config import AppConfig
from hr_pipeline.features import model_columns
from hr_pipeline.logging_utils import get_logger
from hr_pipeline.model import SUPPORTED_MODELS, get_pipeline_from_config

logger = get_logger(__name__)


def evaluate_classifier(
    y_true: pd.Series | np.ndarray,
    y_proba: np.ndarray,
    threshold: float = 0.5,
) -> dict[str, float]:
    """Calcule les métriques de classification binaire.

    Args:
        y_true: vraies classes (0/1).
        y_proba: probabilités prédites pour la classe 1.
        threshold: seuil de décision pour transformer une probabilité en classe.

    Returns:
        Dictionnaire de métriques : ``roc_auc``, ``pr_auc``, ``accuracy``,
        ``precision``, ``recall``, ``f1``.
    """
    y_pred = (np.asarray(y_proba) >= threshold).astype(int)
    return {
        "roc_auc": float(roc_auc_score(y_true, y_proba)),
        "pr_auc": float(average_precision_score(y_true, y_proba)),
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "precision": float(precision_score(y_true, y_pred, zero_division=0)),
        "recall": float(recall_score(y_true, y_pred, zero_division=0)),
        "f1": float(f1_score(y_true, y_pred, zero_division=0)),
    }


def confusion_counts(
    y_true: pd.Series | np.ndarray, y_proba: np.ndarray, threshold: float = 0.5
) -> np.ndarray:
    """Matrice de confusion 2×2 ``[[TN, FP], [FN, TP]]`` au seuil donné."""
    y_pred = (np.asarray(y_proba) >= threshold).astype(int)
    return np.asarray(confusion_matrix(y_true, y_pred, labels=[0, 1]))


def threshold_curve(
    y_true: pd.Series | np.ndarray,
    y_proba: np.ndarray,
    thresholds: np.ndarray | None = None,
) -> pd.DataFrame:
    """Précision, rappel et F1 pour une grille de seuils de décision.

    Quand le seuil est si haut qu'aucun candidat n'est prédit « part », la
    précision et le F1 ne sont pas définis : on renvoie ``NaN`` (et non 0) pour
    ne pas dessiner une chute artificielle.
    """
    grid = np.linspace(0.05, 0.95, 91) if thresholds is None else thresholds
    rows = []
    for t in grid:
        y_pred = (np.asarray(y_proba) >= t).astype(int)
        defined = y_pred.sum() > 0
        rows.append(
            {
                "threshold": float(t),
                "precision": precision_score(y_true, y_pred, zero_division=0)
                if defined
                else np.nan,
                "recall": recall_score(y_true, y_pred, zero_division=0),
                "f1": f1_score(y_true, y_pred, zero_division=0) if defined else np.nan,
            }
        )
    return pd.DataFrame(rows)


def best_f1_threshold(y_true: pd.Series | np.ndarray, y_proba: np.ndarray) -> float:
    """Seuil qui maximise le F1 sur la grille par défaut."""
    curve = threshold_curve(y_true, y_proba)
    return float(curve.loc[curve["f1"].idxmax(), "threshold"])


def compare_models(config: AppConfig, X: pd.DataFrame, y: pd.Series) -> pd.DataFrame:
    """Compare les modèles candidats par validation croisée stratifiée.

    Chaque pli ré-ajuste le pipeline entier (imputation et encodage inclus) :
    aucune information du pli de validation ne fuit vers l'entraînement.

    Args:
        config: configuration (nombre de plis, graine, hyper-paramètres).
        X: variables nettoyées.
        y: cible 0/1.

    Returns:
        Un DataFrame trié par ROC-AUC moyen décroissant.
    """
    cv = StratifiedKFold(
        n_splits=config.model.cv_folds, shuffle=True, random_state=config.project.random_seed
    )
    scoring = {"roc_auc": "roc_auc", "pr_auc": "average_precision", "f1": "f1"}
    rows = []
    for name in SUPPORTED_MODELS:
        if name not in config.model.candidates:
            continue
        pipe = get_pipeline_from_config(config, model_name=name)
        logger.info("Validation croisée : %s", name)
        scores = cross_validate(pipe, X, y, cv=cv, scoring=scoring, n_jobs=1)
        rows.append(
            {
                "model": name,
                "roc_auc_mean": scores["test_roc_auc"].mean(),
                "roc_auc_std": scores["test_roc_auc"].std(),
                "pr_auc_mean": scores["test_pr_auc"].mean(),
                "f1_mean": scores["test_f1"].mean(),
                "fit_time_s": scores["fit_time"].mean(),
            }
        )
    return pd.DataFrame(rows).sort_values("roc_auc_mean", ascending=False).reset_index(drop=True)


def permutation_importance_table(
    pipeline: Pipeline,
    X: pd.DataFrame,
    y: pd.Series,
    config: AppConfig,
    n_repeats: int = 5,
) -> pd.DataFrame:
    """Importance des variables *d'origine* par permutation (métrique : ROC-AUC).

    On mélange une colonne à la fois et on mesure la perte de ROC-AUC : plus la
    perte est grande, plus le modèle s'appuie sur cette colonne. Comme on
    permute les colonnes avant le pré-processeur, on obtient une importance par
    variable lisible (``city``) et non par colonne one-hot (``city_103``).
    """
    cols = model_columns(config.features)
    result = permutation_importance(
        pipeline,
        X[cols],
        y,
        scoring="roc_auc",
        n_repeats=n_repeats,
        random_state=config.project.random_seed,
        n_jobs=1,
    )
    table = pd.DataFrame(
        {
            "feature": cols,
            "importance_mean": result.importances_mean,
            "importance_std": result.importances_std,
        }
    )
    return table.sort_values("importance_mean", ascending=False).reset_index(drop=True)
