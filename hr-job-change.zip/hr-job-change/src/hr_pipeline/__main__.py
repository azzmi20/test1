"""Permet ``python -m hr_pipeline``."""

from hr_pipeline.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
