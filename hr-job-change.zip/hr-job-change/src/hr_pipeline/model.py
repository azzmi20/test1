"""Construction, entraînement et persistance du modèle."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import joblib
import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator
from sklearn.ensemble import HistGradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline

from hr_pipeline.config import AppConfig, FeaturesConfig, ModelConfig
from hr_pipeline.features import build_preprocessor
from hr_pipeline.logging_utils import get_logger

logger = get_logger(__name__)

SUPPORTED_MODELS: tuple[str, ...] = ("logistic_regression", "random_forest", "gradient_boosting")


def build_estimator(name: str, params: dict[str, Any], seed: int) -> BaseEstimator:
    """Instancie l'estimateur scikit-learn correspondant à ``name``.

    Args:
        name: ``logistic_regression``, ``random_forest`` ou ``gradient_boosting``.
        params: hyper-paramètres issus du YAML.
        seed: graine aléatoire pour la reproductibilité.

    Raises:
        ValueError: nom de modèle inconnu.
    """
    if name == "logistic_regression":
        return LogisticRegression(random_state=seed, **params)
    if name == "random_forest":
        return RandomForestClassifier(random_state=seed, **params)
    if name == "gradient_boosting":
        return HistGradientBoostingClassifier(random_state=seed, **params)
    raise ValueError(f"Modèle inconnu '{name}'. Choix possibles : {SUPPORTED_MODELS}")


def build_pipeline(
    features_cfg: FeaturesConfig,
    model_cfg: ModelConfig,
    seed: int,
    model_name: str | None = None,
) -> Pipeline:
    """Assemble pré-processeur + estimateur dans un seul ``Pipeline``.

    Un seul objet à ajuster, sauvegarder et recharger : le pré-traitement
    voyage avec le modèle, donc entraînement et prédiction ne peuvent pas
    diverger.

    Args:
        features_cfg: colonnes du modèle.
        model_cfg: modèle choisi et hyper-paramètres.
        seed: graine aléatoire.
        model_name: force un modèle autre que celui de la configuration
            (utile pour comparer les candidats).
    """
    name = model_name or model_cfg.name
    params = model_cfg.candidates[name]
    return Pipeline(
        [
            ("preprocess", build_preprocessor(features_cfg)),
            ("model", build_estimator(name, params, seed)),
        ]
    )


def split_train_valid(
    X: pd.DataFrame, y: pd.Series, test_size: float, seed: int
) -> tuple[pd.DataFrame, pd.DataFrame, pd.Series, pd.Series]:
    """Découpe stratifiée (la proportion de départs est conservée dans les deux jeux)."""
    return train_test_split(X, y, test_size=test_size, random_state=seed, stratify=y)


def predict_proba(pipeline: Pipeline, X: pd.DataFrame) -> np.ndarray:
    """Probabilité de la classe 1 (le candidat cherche à changer d'emploi)."""
    return np.asarray(pipeline.predict_proba(X)[:, 1])


def save_model(pipeline: Pipeline, path: str | Path) -> Path:
    """Sauvegarde le pipeline complet avec joblib."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(pipeline, path)
    logger.info("Modèle sauvegardé : %s", path)
    return path


def load_model(path: str | Path) -> Pipeline:
    """Recharge un pipeline sauvegardé.

    Raises:
        FileNotFoundError: si le modèle n'a pas encore été entraîné.
    """
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Modèle introuvable : {path}. Lance d'abord l'entraînement.")
    return joblib.load(path)


def get_pipeline_from_config(config: AppConfig, model_name: str | None = None) -> Pipeline:
    """Raccourci : construit le pipeline directement depuis l'``AppConfig``."""
    return build_pipeline(
        config.features, config.model, config.project.random_seed, model_name=model_name
    )
