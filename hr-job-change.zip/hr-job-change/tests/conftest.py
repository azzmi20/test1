"""Fixtures partagées : données synthétiques et configuration de test."""

from __future__ import annotations

from pathlib import Path

import pandas as pd
import pytest
import yaml

from hr_pipeline.config import DEFAULT_CONFIG_PATH, AppConfig, load_config
from hr_pipeline.synthetic import make_synthetic_df


@pytest.fixture(scope="session")
def valid_row() -> dict:
    """Une ligne valide (au format du CSV, ``None`` pour les manquants)."""
    return {
        "enrollee_id": 8949,
        "city": "city_103",
        "city_development_index": 0.92,
        "gender": "Male",
        "relevent_experience": "Has relevent experience",
        "enrolled_university": "no_enrollment",
        "education_level": "Graduate",
        "major_discipline": "STEM",
        "experience": ">20",
        "company_size": None,
        "company_type": None,
        "last_new_job": "1",
        "training_hours": 36,
        "target": 1,
    }


@pytest.fixture(scope="session")
def synthetic_df() -> pd.DataFrame:
    """400 lignes valides avec cible."""
    return make_synthetic_df(n=400, seed=1, with_target=True)


@pytest.fixture()
def tmp_config(tmp_path: Path, synthetic_df: pd.DataFrame) -> AppConfig:
    """Configuration isolée dans un dossier temporaire avec de petits CSV synthétiques."""
    raw = tmp_path / "data" / "raw"
    raw.mkdir(parents=True)
    train = make_synthetic_df(n=600, seed=11, with_target=True)
    test = make_synthetic_df(n=120, seed=12, with_target=False)
    train.to_csv(raw / "aug_train.csv", index=False)
    test.to_csv(raw / "aug_test.csv", index=False)
    pd.DataFrame({"enrollee_id": test["enrollee_id"], "target": 0.5}).to_csv(
        raw / "sample_submission.csv", index=False
    )

    cfg = yaml.safe_load(DEFAULT_CONFIG_PATH.read_text(encoding="utf-8"))
    cfg["model"]["candidates"]["random_forest"]["n_estimators"] = 30
    cfg["model"]["candidates"]["gradient_boosting"]["max_iter"] = 40
    cfg["model"]["cv_folds"] = 3
    cfg_path = tmp_path / "config.yaml"
    cfg_path.write_text(yaml.safe_dump(cfg), encoding="utf-8")
    return load_config(cfg_path, environ={"HR_PROJECT_ROOT": str(tmp_path)}, load_env_file=False)
