"""Tests de l'interface en ligne de commande."""

from __future__ import annotations

import pytest

from hr_pipeline.cli import build_parser, main


def test_parser_requires_a_command():
    with pytest.raises(SystemExit):
        build_parser().parse_args([])


def test_parser_rejects_unknown_model():
    with pytest.raises(SystemExit):
        build_parser().parse_args(["train", "--model", "magic"])


def test_main_returns_2_on_missing_config(tmp_path, capsys):
    code = main(["--config", str(tmp_path / "absent.yaml"), "validate"])
    assert code == 2
    assert "Configuration invalide" in capsys.readouterr().err
