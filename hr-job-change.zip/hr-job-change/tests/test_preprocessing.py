"""Tests du nettoyage déterministe (fonctions pures)."""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from hr_pipeline.preprocessing import (
    clean_dataframe,
    count_missing,
    parse_experience,
    parse_last_new_job,
    rank_company_size,
    rank_education,
)


def test_parse_experience():
    out = parse_experience(pd.Series(["<1", ">20", "7", "20", None]))
    assert out.iloc[:4].tolist() == [0.5, 21.0, 7.0, 20.0]
    assert np.isnan(out.iloc[4])


def test_parse_last_new_job():
    out = parse_last_new_job(pd.Series(["never", ">4", "2", None]))
    assert out.iloc[:3].tolist() == [0.0, 5.0, 2.0]
    assert np.isnan(out.iloc[3])


def test_parse_functions_ignore_garbage_instead_of_crashing():
    assert np.isnan(parse_experience(pd.Series(["abc"])).iloc[0])


def test_company_size_rank_is_ordered():
    sizes = ["<10", "10/49", "50-99", "100-500", "500-999", "1000-4999", "5000-9999", "10000+"]
    assert rank_company_size(pd.Series(sizes)).tolist() == [1, 2, 3, 4, 5, 6, 7, 8]


def test_education_rank_is_ordered():
    levels = ["Primary School", "High School", "Graduate", "Masters", "Phd"]
    assert rank_education(pd.Series(levels)).tolist() == [0, 1, 2, 3, 4]


def test_unknown_modality_becomes_nan():
    assert np.isnan(rank_company_size(pd.Series(["gigantic"])).iloc[0])


def test_count_missing_counts_optional_columns_only(synthetic_df):
    df = synthetic_df.copy()
    df.loc[df.index[0], ["gender", "company_size", "company_type"]] = np.nan
    assert count_missing(df).iloc[0] >= 3
    assert count_missing(df).dtype == "int64"


def test_clean_dataframe_adds_expected_columns(synthetic_df):
    out = clean_dataframe(synthetic_df)
    for column in (
        "experience_years",
        "last_new_job_years",
        "company_size_rank",
        "education_rank",
        "company_size_missing",
        "company_type_missing",
        "is_full_time_student",
        "n_missing",
    ):
        assert column in out.columns
    assert set(out["company_size_missing"].unique()) <= {0, 1}


def test_clean_dataframe_does_not_mutate_input(synthetic_df):
    before = synthetic_df.copy(deep=True)
    clean_dataframe(synthetic_df)
    pd.testing.assert_frame_equal(synthetic_df, before)


def test_clean_dataframe_is_idempotent_on_raw_input(synthetic_df):
    """Relancer le nettoyage donne exactement le même résultat (contrairement au notebook)."""
    pd.testing.assert_frame_equal(clean_dataframe(synthetic_df), clean_dataframe(synthetic_df))


def test_missing_flag_matches_raw_missing(synthetic_df):
    out = clean_dataframe(synthetic_df)
    assert (out["company_size_missing"] == synthetic_df["company_size"].isna()).all()


@pytest.mark.parametrize("n", [1, 5])
def test_clean_dataframe_works_on_tiny_inputs(n):
    from hr_pipeline.synthetic import make_synthetic_df

    assert len(clean_dataframe(make_synthetic_df(n=n, seed=0))) == n
