"""Tests du modèle, de l'évaluation et du pipeline de bout en bout."""

from __future__ import annotations

import json

import numpy as np
import pandas as pd
import pytest

from hr_pipeline.evaluation import (
    best_f1_threshold,
    compare_models,
    evaluate_classifier,
    threshold_curve,
)
from hr_pipeline.features import build_preprocessor, split_features_target
from hr_pipeline.model import build_estimator, load_model
from hr_pipeline.pipeline import prepare_dataset, run_prediction, run_training
from hr_pipeline.preprocessing import clean_dataframe
from hr_pipeline.schemas import DataValidationError
from hr_pipeline.synthetic import corrupt_dataframe


# ------------------------------------------------------------------ features / model
def test_preprocessor_output_has_no_nan(tmp_config, synthetic_df):
    clean = clean_dataframe(synthetic_df)
    X, _ = split_features_target(clean, tmp_config.features)
    out = build_preprocessor(tmp_config.features).fit_transform(X)
    assert not np.isnan(out).any()


def test_preprocessor_handles_unseen_category(tmp_config, synthetic_df):
    clean = clean_dataframe(synthetic_df)
    X, _ = split_features_target(clean, tmp_config.features)
    prep = build_preprocessor(tmp_config.features).fit(X)
    unseen = X.head(3).copy()
    unseen["city"] = "city_99999"
    assert prep.transform(unseen).shape[0] == 3


def test_split_features_target_requires_target(tmp_config, synthetic_df):
    with pytest.raises(KeyError):
        split_features_target(synthetic_df.drop(columns="target"), tmp_config.features)


def test_unknown_model_name_is_rejected():
    with pytest.raises(ValueError, match="Modèle inconnu"):
        build_estimator("magic_forest", {}, seed=0)


# ------------------------------------------------------------------------ évaluation
def test_evaluate_classifier_perfect_and_random():
    y = np.array([0, 0, 1, 1])
    perfect = evaluate_classifier(y, np.array([0.1, 0.2, 0.8, 0.9]))
    assert perfect["roc_auc"] == 1.0 and perfect["f1"] == 1.0
    assert set(perfect) == {"roc_auc", "pr_auc", "accuracy", "precision", "recall", "f1"}


def test_threshold_curve_has_nan_when_nothing_predicted():
    y = np.array([0, 1, 0, 1])
    curve = threshold_curve(y, np.array([0.1, 0.4, 0.2, 0.3]), thresholds=np.array([0.2, 0.99]))
    assert np.isnan(curve.loc[1, "precision"])
    assert curve.loc[1, "recall"] == 0.0


def test_best_threshold_is_within_grid():
    rng = np.random.default_rng(0)
    y = rng.integers(0, 2, 300)
    proba = np.clip(y * 0.3 + rng.random(300) * 0.7, 0, 1)
    assert 0.05 <= best_f1_threshold(y, proba) <= 0.95


def test_compare_models_returns_one_row_per_model(tmp_config, synthetic_df):
    clean = clean_dataframe(synthetic_df)
    X, y = split_features_target(clean, tmp_config.features)
    table = compare_models(tmp_config, X, y)
    assert set(table["model"]) == {"logistic_regression", "random_forest", "gradient_boosting"}
    assert table["roc_auc_mean"].is_monotonic_decreasing


# ----------------------------------------------------------------------- bout en bout
def test_training_is_reproducible(tmp_config):
    first = run_training(tmp_config, save=False)
    second = run_training(tmp_config, save=False)
    assert first.metrics["validation"] == second.metrics["validation"]


def test_training_learns_something_on_synthetic_signal(tmp_config):
    result = run_training(tmp_config, save=False)
    assert result.metrics["validation"]["roc_auc"] > 0.6


@pytest.mark.parametrize("name", ["logistic_regression", "random_forest", "gradient_boosting"])
def test_each_model_trains(tmp_config, name):
    result = run_training(tmp_config, model_name=name, save=False)
    assert result.metrics["model"] == name
    assert len(result.proba_valid) == result.metrics["n_valid"]


def test_train_then_predict_writes_valid_submission(tmp_config):
    run_training(tmp_config, save=True)
    assert tmp_config.model_path.exists()
    metrics = json.loads(tmp_config.metrics_path.read_text(encoding="utf-8"))
    assert "roc_auc" in metrics["validation"]

    submission = run_prediction(tmp_config)  # recharge le modèle sauvegardé
    template = pd.read_csv(tmp_config.template_path)
    assert list(submission.columns) == ["enrollee_id", "target"]
    assert submission["enrollee_id"].tolist() == template["enrollee_id"].tolist()
    assert submission["target"].between(0, 1).all()
    assert tmp_config.submission_path.exists()


def test_saved_model_gives_same_predictions_as_in_memory(tmp_config):
    result = run_training(tmp_config, save=True)
    reloaded = load_model(tmp_config.model_path)
    np.testing.assert_allclose(
        reloaded.predict_proba(result.X_valid)[:, 1], result.proba_valid, rtol=1e-9
    )


def test_predict_without_trained_model_fails_clearly(tmp_config):
    with pytest.raises(FileNotFoundError, match="Lance d'abord l'entraînement"):
        run_prediction(tmp_config)


def test_prepare_dataset_quarantines_bad_rows(tmp_config, synthetic_df):
    base = synthetic_df.drop(columns="target")
    corrupted, truth = corrupt_dataframe(base, rate=0.03, seed=4)
    clean, rejected, report = prepare_dataset(corrupted, tmp_config)
    assert len(rejected) == len(truth) == report.rejected
    assert tmp_config.rejected_path.exists()
    assert "experience_years" in clean.columns


def test_prepare_dataset_stops_on_massive_corruption(tmp_config, synthetic_df):
    corrupted, _ = corrupt_dataframe(synthetic_df.drop(columns="target"), rate=0.4, seed=4)
    with pytest.raises(DataValidationError):
        prepare_dataset(corrupted, tmp_config)
