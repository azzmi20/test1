"""Tests de la séparation code / configuration."""

from __future__ import annotations

import pytest
import yaml
from pydantic import ValidationError

from hr_pipeline.config import DEFAULT_CONFIG_PATH, apply_env_overrides, load_config


def test_default_config_is_valid():
    cfg = load_config(environ={"HR_PROJECT_ROOT": str(DEFAULT_CONFIG_PATH.parents[1])})
    assert cfg.model.name == "gradient_boosting"
    assert cfg.train_path.name == "aug_train.csv"
    assert cfg.project.random_seed == 42


def test_env_variables_override_yaml():
    cfg = load_config(
        environ={"HR_ENV": "prod", "HR_RANDOM_SEED": "7", "HR_LOG_LEVEL": "debug"},
        load_env_file=False,
    )
    assert cfg.project.env == "prod"
    assert cfg.project.random_seed == 7
    assert cfg.project.log_level == "DEBUG"


def test_empty_env_variable_is_ignored():
    raw = {"project": {"env": "dev"}}
    assert apply_env_overrides(raw, {"HR_ENV": ""})["project"]["env"] == "dev"


@pytest.mark.parametrize(
    "environ",
    [{"HR_ENV": "preprod"}, {"HR_RANDOM_SEED": "-3"}, {"HR_MAX_REJECTION_RATE": "2"}],
)
def test_invalid_environment_values_fail_at_startup(environ):
    with pytest.raises(ValidationError):
        load_config(environ=environ, load_env_file=False)


def test_missing_yaml_raises(tmp_path):
    with pytest.raises(FileNotFoundError):
        load_config(tmp_path / "nope.yaml", environ={"X": "1"}, load_env_file=False)


def test_unknown_key_in_yaml_is_rejected(tmp_path):
    raw = yaml.safe_load(DEFAULT_CONFIG_PATH.read_text(encoding="utf-8"))
    raw["model"]["tets_size"] = 0.3  # faute de frappe volontaire
    path = tmp_path / "bad.yaml"
    path.write_text(yaml.safe_dump(raw), encoding="utf-8")
    with pytest.raises(ValidationError, match="tets_size"):
        load_config(path, environ={"X": "1"}, load_env_file=False)


def test_model_without_candidate_block_is_rejected(tmp_path):
    raw = yaml.safe_load(DEFAULT_CONFIG_PATH.read_text(encoding="utf-8"))
    del raw["model"]["candidates"]["random_forest"]
    raw["model"]["name"] = "random_forest"
    path = tmp_path / "bad.yaml"
    path.write_text(yaml.safe_dump(raw), encoding="utf-8")
    with pytest.raises(ValidationError, match="candidates"):
        load_config(path, environ={"X": "1"}, load_env_file=False)


def test_relative_paths_are_resolved_from_root(tmp_path):
    cfg = load_config(environ={"HR_PROJECT_ROOT": str(tmp_path)}, load_env_file=False)
    assert cfg.model_path == tmp_path / "models" / "model.joblib"
