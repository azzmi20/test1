"""Tests du schéma Pydantic : il doit REJETER les données corrompues (TP 2)."""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest
from pydantic import ValidationError

from hr_pipeline.config import ValidationConfig
from hr_pipeline.schemas import (
    CompanySize,
    DataValidationError,
    EnrolleeRecord,
    ValidationReport,
    build_record_model,
    check_columns,
    validate_dataframe,
)
from hr_pipeline.synthetic import CORRUPTION_KINDS, corrupt_dataframe, make_synthetic_df


# --------------------------------------------------------------------------- ligne
def test_valid_row_is_accepted(valid_row):
    record = EnrolleeRecord.model_validate(valid_row)
    assert record.enrollee_id == 8949
    assert record.company_size is None  # le manquant est légitime


def test_stray_whitespace_is_rejected_not_silently_fixed(valid_row):
    """Strict : " Male " serait sinon encodé comme une modalité distincte de "Male"."""
    with pytest.raises(ValidationError):
        EnrolleeRecord.model_validate({**valid_row, "gender": "  Male "})


def test_dataset_label_with_slash_is_accepted(valid_row):
    record = EnrolleeRecord.model_validate({**valid_row, "company_size": "10/49"})
    assert record.company_size is CompanySize.S_10_49


@pytest.mark.parametrize(
    ("field", "value"),
    [
        ("city_development_index", 1.7),
        ("city_development_index", -0.1),
        ("city_development_index", float("inf")),
        ("training_hours", -5),
        ("training_hours", 0),
        ("training_hours", "abc"),
        ("enrollee_id", 0),
        ("city", "Paris"),
        ("city", "city_"),
        ("gender", "Unknown?"),
        ("relevent_experience", "maybe"),
        ("education_level", "Kindergarten"),
        ("experience", "99"),
        ("experience", "-1"),
        ("last_new_job", "7"),
        ("company_size", "huge"),
        ("target", 2),
    ],
)
def test_corrupted_value_is_rejected(valid_row, field, value):
    with pytest.raises(ValidationError) as excinfo:
        EnrolleeRecord.model_validate({**valid_row, field: value})
    assert any(err["loc"][0] == field for err in excinfo.value.errors())


def test_unknown_column_is_rejected(valid_row):
    with pytest.raises(ValidationError):
        EnrolleeRecord.model_validate({**valid_row, "surprise": 1})


def test_missing_required_field_is_rejected(valid_row):
    row = {k: v for k, v in valid_row.items() if k != "training_hours"}
    with pytest.raises(ValidationError):
        EnrolleeRecord.model_validate(row)


def test_target_is_optional_for_test_file(valid_row):
    row = {k: v for k, v in valid_row.items() if k != "target"}
    assert EnrolleeRecord.model_validate(row).target is None


# --------------------------------------------------------------------- configurable
def test_bounds_come_from_configuration(valid_row):
    strict = build_record_model(ValidationConfig(training_hours_max=50))
    with pytest.raises(ValidationError):
        strict.model_validate({**valid_row, "training_hours": 51})
    assert strict.model_validate({**valid_row, "training_hours": 50}).training_hours == 50


def test_invalid_validation_config_is_refused():
    with pytest.raises(ValidationError):
        ValidationConfig(cdi_min=1.0, cdi_max=0.5)


# --------------------------------------------------------------------------- DataFrame
def test_clean_dataframe_is_fully_accepted(synthetic_df):
    valid, rejected, report = validate_dataframe(synthetic_df)
    assert len(valid) == len(synthetic_df)
    assert rejected.empty
    assert report.rejected == 0
    assert report.rejection_rate == 0.0


def test_nan_is_treated_as_missing_not_error(synthetic_df):
    df = synthetic_df.copy()
    df.loc[df.index[:20], "gender"] = np.nan
    _, rejected, _ = validate_dataframe(df)
    assert rejected.empty


def test_every_injected_corruption_is_detected():
    base = make_synthetic_df(n=1000, seed=3, with_target=False)
    corrupted, truth = corrupt_dataframe(base, rate=0.15, seed=5)
    valid, rejected, report = validate_dataframe(corrupted)

    assert set(rejected.index) == set(truth)  # ni oubli, ni fausse alerte
    assert len(valid) + len(rejected) == len(base)
    assert report.rejected == len(truth)
    assert "validation_errors" in rejected.columns


@pytest.mark.parametrize("kind", list(CORRUPTION_KINDS))
def test_each_corruption_kind_is_detected(kind, monkeypatch):
    """Chaque type de corruption, pris isolément, est bien rejeté."""
    import hr_pipeline.synthetic as synthetic

    base = make_synthetic_df(n=60, seed=8, with_target=False)
    monkeypatch.setattr(synthetic, "CORRUPTION_KINDS", {kind: CORRUPTION_KINDS[kind]})
    corrupted, truth = synthetic.corrupt_dataframe(base, rate=0.5, seed=1)
    _, rejected, _ = validate_dataframe(corrupted)
    assert set(rejected.index) == set(truth)
    assert len(truth) > 0


def test_rejected_rows_explain_why(valid_row):
    df = pd.DataFrame([{**valid_row, "city_development_index": 1.7}])
    _, rejected, report = validate_dataframe(df)
    assert "city_development_index" in rejected.iloc[0]["validation_errors"]
    assert report.errors_by_field == {"city_development_index": 1}


def test_too_many_rejections_stops_the_pipeline():
    base = make_synthetic_df(n=200, seed=2, with_target=False)
    corrupted, _ = corrupt_dataframe(base, rate=0.3, seed=2)
    with pytest.raises(DataValidationError, match="Taux de rejet"):
        validate_dataframe(corrupted, max_rejection_rate=0.05)


def test_low_rejection_rate_is_tolerated():
    base = make_synthetic_df(n=400, seed=2, with_target=False)
    corrupted, _ = corrupt_dataframe(base, rate=0.02, seed=2)
    valid, rejected, _ = validate_dataframe(corrupted, max_rejection_rate=0.05)
    assert len(rejected) > 0 and len(valid) > 0


def test_unexpected_or_missing_columns_are_refused(synthetic_df):
    with pytest.raises(DataValidationError, match="inattendues"):
        check_columns(synthetic_df.assign(extra=1))
    with pytest.raises(DataValidationError, match="manquantes"):
        check_columns(synthetic_df.drop(columns=["training_hours"]))


def test_validation_does_not_modify_input(synthetic_df):
    before = synthetic_df.copy(deep=True)
    validate_dataframe(synthetic_df)
    pd.testing.assert_frame_equal(synthetic_df, before)


def test_report_summary_and_dict():
    report = ValidationReport(total=10, valid=8, rejected=2, errors_by_field={"gender": 2})
    assert "20.00%" in report.summary()
    assert report.to_dict()["rejection_rate"] == 0.2
