# hr-job-change — du notebook au code production

Prédire si un candidat data scientist **cherche à changer d'emploi** (jeu *HR Analytics : Job Change of Data Scientists*, 19 158 candidats, 25 % de départs).

Ce projet est le livrable des deux premières séquences du cours **« Du notebook au code production »** :

| Séquence | Objectif | Où le voir |
|---|---|---|
| **1** — Du notebook au code production | Refactoriser un notebook désordonné en modules `.py` propres, arborescence `src/ configs/ tests/ data/`, gestionnaire de dépendances moderne | `notebooks/00_…AVANT` → `src/hr_pipeline/` + `docs/REFACTORING.md` |
| **2** — Typage, validation & configuration | Type hints, schéma **Pydantic** qui rejette les données corrompues, séparation code / configuration (YAML, `.env`) | `src/hr_pipeline/schemas.py`, `config.py`, `configs/config.yaml`, `.env.example` |

## Démarrage rapide

```bash
# 1) Environnement (au choix)
uv sync --extra dev                  # uv : crée .venv et installe tout
# poetry install --extras dev        # poetry 2.x lit directement le bloc [project]
# python -m venv .venv && source .venv/bin/activate && pip install -e ".[dev]"   # pip classique

# 2) Configuration locale (optionnel)
cp .env.example .env

# 3) Utilisation
python -m hr_pipeline validate       # contrôle des CSV avec Pydantic
python -m hr_pipeline compare        # compare 3 modèles par validation croisée
python -m hr_pipeline train          # entraîne -> models/model.joblib + metrics.json
python -m hr_pipeline predict        # écrit data/processed/submission.csv
python -m hr_pipeline figures        # régénère les 12 graphiques dans reports/figures/

# 4) Qualité
pytest                               # 86 tests
ruff check src tests && mypy src     # lint + analyse statique
```

Codes de sortie de la CLI : `0` succès · `2` configuration invalide · `3` données refusées par la validation · `4` fichier manquant.

## Résultats

| Modèle | ROC-AUC (CV 5 plis) | PR-AUC | F1 |
|---|---|---|---|
| gradient boosting (défaut) | **0,805 ± 0,003** | 0,551 | 0,631 |
| random forest | 0,802 ± 0,002 | 0,545 | 0,628 |
| régression logistique | 0,796 ± 0,005 | 0,538 | 0,619 |

Sur le jeu de validation (20 %, stratifié, seuil 0,5) : ROC-AUC **0,822**, rappel 0,78, précision 0,56, F1 0,65.
Les trois modèles sont proches : les écarts sont de l'ordre de l'écart-type, il ne faut pas les sur-interpréter.

**Ce que dit le modèle** (associations, pas causalité) : l'indice de développement de la ville est la variable la plus utile, suivie de l'indicateur « taille d'entreprise manquante » — une valeur manquante peut être informative.

Les 12 graphiques sont dans `reports/figures/` et commentés dans le notebook `01_notebook_propre_APRES.ipynb`.

## Arborescence

```
hr-job-change/
├── pyproject.toml              # dépendances, pytest, ruff, mypy
├── uv.lock                     # versions exactes verrouillées (uv)
├── .env.example                # variables d'environnement (copier vers .env)
├── configs/config.yaml         # paramètres versionnés
├── data/
│   ├── raw/                    # aug_train.csv, aug_test.csv, sample_submission.csv
│   └── processed/              # submission.csv, rejected_rows.csv (générés)
├── models/                     # model.joblib, metrics.json (générés)
├── notebooks/
│   ├── 00_notebook_desordonne_AVANT.ipynb   # point de départ du TP 1
│   └── 01_notebook_propre_APRES.ipynb       # version refactorisée, avec graphiques
├── reports/figures/            # 12 graphiques PNG
├── docs/
│   ├── REFACTORING.md          # guide pas à pas du TP 1 (cellule -> module)
│   └── GLOSSAIRE_FONCTIONS.md  # toutes les fonctions (def), généré depuis les docstrings
├── scripts/generate_api_doc.py
├── src/hr_pipeline/
│   ├── config.py               # YAML + .env + validation Pydantic de la config
│   ├── schemas.py              # schéma Pydantic des lignes, validate_dataframe, quarantaine
│   ├── data_loader.py          # lecture / écriture CSV
│   ├── preprocessing.py        # conversions déterministes (fonctions pures)
│   ├── features.py             # ColumnTransformer (imputation, encodage, standardisation)
│   ├── model.py                # construction / sauvegarde du modèle
│   ├── evaluation.py           # métriques, validation croisée, importance
│   ├── visualization.py        # 12 types de graphiques
│   ├── pipeline.py             # orchestration validation -> entraînement -> prédiction
│   ├── reporting.py            # génération de toutes les figures
│   ├── synthetic.py            # données de test, valides ou corrompues
│   ├── logging_utils.py        # logs (remplacent les print)
│   └── cli.py                  # python -m hr_pipeline <commande>
└── tests/                      # 86 tests pytest
```

## Séquence 1 — ce qui change par rapport au notebook

| Limite du notebook | Réponse dans le projet |
|---|---|
| État global, ordre d'exécution | fonctions pures, entrée -> sortie ; le DataFrame d'origine n'est jamais modifié |
| Cellules non idempotentes (`cdi * 100` relancé = résultat faux) | `clean_dataframe` recalcule depuis le brut ; test d'idempotence |
| Fuite de données (médiane et scaler sur tout le jeu) | imputation / standardisation **dans** le `Pipeline` scikit-learn |
| Pas de graine, scores qui varient | une graine dans `config.yaml` ; test de reproductibilité |
| Impossible de prédire sur le jeu de test | le pipeline complet est sauvegardé avec `joblib` |
| Dépendances implicites | déclarées dans `pyproject.toml` |

## Séquence 2 — typage, validation, configuration

- **Type hints** sur toutes les fonctions, vérifiés par `mypy` (`disallow_untyped_defs`).
- **Pydantic** (`schemas.py`) : types, bornes, modalités autorisées, colonnes inconnues interdites. Les lignes invalides vont en **quarantaine** (`data/processed/rejected_rows.csv`) avec la raison ; au-delà de 5 % de rejet, le pipeline s'arrête.
- **Validation stricte, sans réparation silencieuse** : `" Male "` est rejeté (au lieu d'être accepté puis encodé comme une modalité fantôme).
- **Bornes configurables** : `build_record_model(config.validation)` construit le schéma depuis le YAML.
- **Configuration** : `config.yaml` (versionné) < `.env` (local, ignoré par git) < variables d'environnement `HR_*`. Une configuration invalide (`HR_ENV=preprod`, clé mal orthographiée) échoue au démarrage.

La preuve par le test : `corrupt_dataframe` injecte 8 types de corruption ; `tests/test_schemas.py` vérifie que **toutes** sont détectées, sans fausse alerte.

## Limites et pistes

- La corrélation n'est pas la causalité : l'importance des variables décrit le modèle, pas les raisons réelles des départs.
- Le seuil de décision (0,5) est un choix métier ; la courbe précision / rappel (`reports/figures/11_…`) aide à l'ajuster.
- Pistes : optimisation d'hyper-paramètres, suivi d'expériences (MLflow), intégration continue (GitHub Actions : `ruff`, `mypy`, `pytest`), API de prédiction (FastAPI réutilisant `EnrolleeRecord`).
