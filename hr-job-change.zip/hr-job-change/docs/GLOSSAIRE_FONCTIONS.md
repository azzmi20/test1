# Glossaire des fonctions (`def`) et classes du projet

> Fichier **généré automatiquement** par `scripts/generate_api_doc.py` à partir des docstrings. Ne pas modifier à la main.
**61 fonctions publiques et 17 classes** réparties en 13 modules.


## `config.py`

_Chargement et validation de la configuration._

| Fonction | Signature | Rôle |
|---|---|---|
| `def apply_env_overrides` | `(raw: dict[str, Any], environ: dict[str, str] \| None=None) -> dict[str, Any]` | Applique les variables ``HR_*`` par-dessus le dictionnaire issu du YAML. |
| `def load_config` | `(path: str \| Path \| None=None, environ: dict[str, str] \| None=None, load_env_file: bool=True) -> AppConfig` | Charge, surcharge puis valide la configuration. |

| Classe | Rôle |
|---|---|
| `class ProjectConfig` | Paramètres généraux du projet. |
| `class PathsConfig` | Chemins relatifs à la racine du projet. |
| `class ValidationConfig` | Bornes utilisées par le schéma Pydantic de validation des données. |
| `class FeaturesConfig` | Description des colonnes utilisées par le modèle. |
| `class ModelConfig` | Choix du modèle et hyper-paramètres. |
| `class AppConfig` | Configuration complète de l'application. |

## `schemas.py`

_Schémas Pydantic : validation stricte des données entrantes (Séquence 2)._

| Fonction | Signature | Rôle |
|---|---|---|
| `def build_record_model` | `(cfg: ValidationConfig \| None=None) -> type[EnrolleeRecord]` | Construit un schéma dont les bornes viennent de la configuration. |
| `def check_columns` | `(df: pd.DataFrame, model: type[BaseModel]=EnrolleeRecord) -> None` | Vérifie que les colonnes du DataFrame correspondent au schéma. |
| `def validate_dataframe` | `(df: pd.DataFrame, model: type[BaseModel]=EnrolleeRecord, max_rejection_rate: float \| None=None) -> tuple[pd.DataFrame, pd.DataFrame, ValidationReport]` | Valide chaque ligne du DataFrame contre le schéma Pydantic. |

| Classe | Rôle |
|---|---|
| `class Gender` | Genre déclaré du candidat. |
| `class RelevantExperience` | Le candidat a-t-il une expérience pertinente en data science ? |
| `class EnrolledUniversity` | Type de cursus universitaire en cours. |
| `class EducationLevel` | Niveau d'études le plus élevé. |
| `class MajorDiscipline` | Discipline principale des études supérieures. |
| `class CompanySize` | Tranche d'effectif de l'entreprise actuelle. |
| `class CompanyType` | Type d'entreprise actuelle. |
| `class EnrolleeRecord` | Contrat d'une ligne du fichier ``aug_train.csv`` / ``aug_test.csv``. |
| `class DataValidationError` | Levée quand le jeu de données est globalement inacceptable. |
| `class ValidationReport` | Résumé chiffré d'une validation de DataFrame. |

## `data_loader.py`

_Lecture des fichiers de données (aucune transformation ici)._

| Fonction | Signature | Rôle |
|---|---|---|
| `def read_csv` | `(path: str \| Path) -> pd.DataFrame` | Lit un CSV en vérifiant que le fichier existe et n'est pas vide. |
| `def load_train` | `(config: AppConfig) -> pd.DataFrame` | Charge le jeu d'entraînement défini dans la configuration. |
| `def load_test` | `(config: AppConfig) -> pd.DataFrame` | Charge le jeu de test (sans la colonne ``target``). |
| `def load_submission_template` | `(config: AppConfig) -> pd.DataFrame` | Charge le modèle de fichier de soumission (``enrollee_id``, ``target``). |
| `def save_csv` | `(df: pd.DataFrame, path: str \| Path, index: bool=False) -> Path` | Écrit un CSV en créant les dossiers parents si besoin. |

## `preprocessing.py`

_Nettoyage *sans état* : conversion des colonnes textuelles en nombres._

| Fonction | Signature | Rôle |
|---|---|---|
| `def parse_experience` | `(series: pd.Series) -> pd.Series` | Convertit la colonne ``experience`` en années (float). |
| `def parse_last_new_job` | `(series: pd.Series) -> pd.Series` | Convertit ``last_new_job`` (années depuis le dernier changement) en float. |
| `def rank_company_size` | `(series: pd.Series) -> pd.Series` | Encode la taille d'entreprise en rang ordinal de 1 (<10) à 8 (10000+). |
| `def rank_education` | `(series: pd.Series) -> pd.Series` | Encode le niveau d'études en rang ordinal de 0 (primaire) à 4 (doctorat). |
| `def count_missing` | `(df: pd.DataFrame, columns: list[str] \| None=None) -> pd.Series` | Compte, pour chaque ligne, le nombre de colonnes optionnelles manquantes. |
| `def clean_dataframe` | `(df: pd.DataFrame) -> pd.DataFrame` | Applique toutes les conversions déterministes et ajoute les variables dérivées. |

## `features.py`

_Construction du pré-processeur scikit-learn (partie *avec état*)._

| Fonction | Signature | Rôle |
|---|---|---|
| `def split_features_target` | `(df: pd.DataFrame, cfg: FeaturesConfig) -> tuple[pd.DataFrame, pd.Series]` | Sépare la matrice de variables ``X`` de la cible ``y``. |
| `def model_columns` | `(cfg: FeaturesConfig) -> list[str]` | Liste ordonnée des colonnes réellement consommées par le modèle. |
| `def build_preprocessor` | `(cfg: FeaturesConfig) -> ColumnTransformer` | Construit le ``ColumnTransformer`` du projet. |

## `model.py`

_Construction, entraînement et persistance du modèle._

| Fonction | Signature | Rôle |
|---|---|---|
| `def build_estimator` | `(name: str, params: dict[str, Any], seed: int) -> BaseEstimator` | Instancie l'estimateur scikit-learn correspondant à ``name``. |
| `def build_pipeline` | `(features_cfg: FeaturesConfig, model_cfg: ModelConfig, seed: int, model_name: str \| None=None) -> Pipeline` | Assemble pré-processeur + estimateur dans un seul ``Pipeline``. |
| `def split_train_valid` | `(X: pd.DataFrame, y: pd.Series, test_size: float, seed: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.Series, pd.Series]` | Découpe stratifiée (la proportion de départs est conservée dans les deux jeux). |
| `def predict_proba` | `(pipeline: Pipeline, X: pd.DataFrame) -> np.ndarray` | Probabilité de la classe 1 (le candidat cherche à changer d'emploi). |
| `def save_model` | `(pipeline: Pipeline, path: str \| Path) -> Path` | Sauvegarde le pipeline complet avec joblib. |
| `def load_model` | `(path: str \| Path) -> Pipeline` | Recharge un pipeline sauvegardé. |
| `def get_pipeline_from_config` | `(config: AppConfig, model_name: str \| None=None) -> Pipeline` | Raccourci : construit le pipeline directement depuis l'``AppConfig``. |

## `evaluation.py`

_Métriques, comparaison de modèles et importance des variables._

| Fonction | Signature | Rôle |
|---|---|---|
| `def evaluate_classifier` | `(y_true: pd.Series \| np.ndarray, y_proba: np.ndarray, threshold: float=0.5) -> dict[str, float]` | Calcule les métriques de classification binaire. |
| `def confusion_counts` | `(y_true: pd.Series \| np.ndarray, y_proba: np.ndarray, threshold: float=0.5) -> np.ndarray` | Matrice de confusion 2×2 ``[[TN, FP], [FN, TP]]`` au seuil donné. |
| `def threshold_curve` | `(y_true: pd.Series \| np.ndarray, y_proba: np.ndarray, thresholds: np.ndarray \| None=None) -> pd.DataFrame` | Précision, rappel et F1 pour une grille de seuils de décision. |
| `def best_f1_threshold` | `(y_true: pd.Series \| np.ndarray, y_proba: np.ndarray) -> float` | Seuil qui maximise le F1 sur la grille par défaut. |
| `def compare_models` | `(config: AppConfig, X: pd.DataFrame, y: pd.Series) -> pd.DataFrame` | Compare les modèles candidats par validation croisée stratifiée. |
| `def permutation_importance_table` | `(pipeline: Pipeline, X: pd.DataFrame, y: pd.Series, config: AppConfig, n_repeats: int=5) -> pd.DataFrame` | Importance des variables *d'origine* par permutation (métrique : ROC-AUC). |

## `visualization.py`

_Graphiques du projet (matplotlib)._

| Fonction | Signature | Rôle |
|---|---|---|
| `def apply_style` | `() -> None` | Applique le style graphique commun (appelé automatiquement). |
| `def save_figure` | `(fig: Figure, path: str \| Path, dpi: int=150) -> Path` | Enregistre une figure en créant le dossier si besoin. |
| `def plot_target_distribution` | `(df: pd.DataFrame, target: str='target', save_to: str \| Path \| None=None) -> Figure` | Barres : effectif et part des deux classes (déséquilibre de la cible). |
| `def plot_missing_values` | `(df: pd.DataFrame, save_to: str \| Path \| None=None) -> Figure` | Barres horizontales : pourcentage de valeurs manquantes par colonne. |
| `def plot_numeric_by_target` | `(df: pd.DataFrame, columns: Sequence[str]=('city_development_index', 'training_hours'), target: str='target', save_to: str \| Path \| None=None) -> Figure` | Histogrammes normalisés par classe (une case par variable numérique). |
| `def plot_rate_by_category` | `(df: pd.DataFrame, columns: Sequence[str], target: str='target', save_to: str \| Path \| None=None) -> Figure` | Taux de départ par modalité (petits multiples), avec la moyenne globale en repère. |
| `def plot_rate_by_cdi` | `(df: pd.DataFrame, target: str='target', bins: int=10, save_to: str \| Path \| None=None) -> Figure` | Taux de départ par tranche d'indice de développement de la ville. |
| `def plot_correlation` | `(df: pd.DataFrame, columns: Sequence[str], target: str='target', save_to: str \| Path \| None=None) -> Figure` | Matrice de corrélation (divergente bleu ↔ orange, gris au centre). |
| `def plot_model_comparison` | `(cv_table: pd.DataFrame, save_to: str \| Path \| None=None) -> Figure` | ROC-AUC moyen (± écart-type) de chaque modèle en validation croisée. |
| `def plot_roc_pr` | `(y_true: pd.Series \| np.ndarray, y_proba: np.ndarray, save_to: str \| Path \| None=None) -> Figure` | Courbes ROC et précision-rappel côte à côte. |
| `def plot_confusion` | `(cm: np.ndarray, threshold: float=0.5, save_to: str \| Path \| None=None) -> Figure` | Matrice de confusion : effectifs et part par classe réelle. |
| `def plot_feature_importance` | `(table: pd.DataFrame, top: int=12, save_to: str \| Path \| None=None) -> Figure` | Importance par permutation (perte de ROC-AUC), top-N variables. |
| `def plot_threshold_tradeoff` | `(curve: pd.DataFrame, chosen: float=0.5, save_to: str \| Path \| None=None) -> Figure` | Précision, rappel et F1 selon le seuil de décision. |
| `def plot_validation_report` | `(report: ValidationReport, title: str \| None=None, save_to: str \| Path \| None=None) -> Figure` | Nombre de lignes rejetées par champ fautif (démonstration du schéma). |

## `pipeline.py`

_Orchestration de bout en bout : validation → nettoyage → entraînement → prédiction._

| Fonction | Signature | Rôle |
|---|---|---|
| `def prepare_dataset` | `(raw: pd.DataFrame, config: AppConfig, save_rejected: bool=True) -> tuple[pd.DataFrame, pd.DataFrame, ValidationReport]` | Valide puis nettoie un DataFrame brut. |
| `def run_training` | `(config: AppConfig, model_name: str \| None=None, save: bool=True) -> TrainingResult` | Entraîne le modèle et évalue sur un jeu de validation stratifié. |
| `def run_prediction` | `(config: AppConfig, pipeline: Pipeline \| None=None) -> pd.DataFrame` | Prédit les probabilités sur le jeu de test et écrit la soumission. |

| Classe | Rôle |
|---|---|
| `class TrainingResult` | Tout ce que produit un entraînement (pratique pour le notebook). |

## `reporting.py`

_Génération de tous les graphiques du rapport en une commande._

| Fonction | Signature | Rôle |
|---|---|---|
| `def generate_all_figures` | `(config: AppConfig) -> list[Path]` | Produit les 12 figures du rapport dans ``reports/figures/``. |

## `synthetic.py`

_Données synthétiques : valides (pour les tests) ou volontairement corrompues._

| Fonction | Signature | Rôle |
|---|---|---|
| `def make_synthetic_df` | `(n: int=500, seed: int=0, with_target: bool=True) -> pd.DataFrame` | Génère ``n`` lignes **valides** vis-à-vis du schéma. |
| `def corrupt_dataframe` | `(df: pd.DataFrame, rate: float=0.1, seed: int=0) -> tuple[pd.DataFrame, dict[int, str]]` | Corrompt volontairement une fraction des lignes. |

## `logging_utils.py`

_Configuration centralisée des logs (remplace les ``print`` des notebooks)._

| Fonction | Signature | Rôle |
|---|---|---|
| `def setup_logging` | `(level: str='INFO') -> None` | Configure le logging racine une seule fois. |
| `def get_logger` | `(name: str) -> logging.Logger` | Renvoie un logger nommé (convention : ``get_logger(__name__)``). |

## `cli.py`

_Interface en ligne de commande._

| Fonction | Signature | Rôle |
|---|---|---|
| `def build_parser` | `() -> argparse.ArgumentParser` | Construit le parseur d'arguments (une sous-commande par action). |
| `def cmd_validate` | `(config: AppConfig) -> int` | Valide les fichiers train et test, affiche les rapports. |
| `def cmd_compare` | `(config: AppConfig) -> int` | Affiche le tableau de comparaison des modèles. |
| `def cmd_train` | `(config: AppConfig, model: str \| None) -> int` | Entraîne le modèle et affiche les métriques. |
| `def cmd_predict` | `(config: AppConfig) -> int` | Écrit le fichier de soumission. |
| `def cmd_figures` | `(config: AppConfig) -> int` | Génère tous les graphiques du rapport. |
| `def main` | `(argv: Sequence[str] \| None=None) -> int` | Point d'entrée. Renvoie un code de sortie (0 = succès). |
