# Guide de refactorisation (TP 1) — du notebook aux modules

Ce guide suit le notebook `notebooks/00_notebook_desordonne_AVANT.ipynb` cellule par cellule et indique **où va chaque morceau** dans `src/hr_pipeline/`.

## 1. Méthode en 6 étapes

1. **Lire sans modifier** : lister les défauts (état global, valeurs magiques, fuites, duplications).
2. **Figer le comportement** : noter les résultats du notebook (ici : *accuracy* ≈ 0,77 — qui n'est que +2 points au-dessus du « toujours rester » à 0,75).
3. **Découper par responsabilité** : lecture, validation, nettoyage, variables, modèle, évaluation, graphiques.
4. **Transformer chaque morceau en fonction pure** : arguments explicites, valeur de retour, pas de variable globale, pas de modification de l'argument.
5. **Sortir les paramètres** vers `configs/config.yaml` et `.env`.
6. **Écrire les tests** avant de supprimer l'ancien code, puis ne garder dans le notebook que des appels de fonctions.

## 2. Table de correspondance

| Cellule du notebook « AVANT » | Défaut | Destination | Fonction(s) |
|---|---|---|---|
| `pd.read_csv('../data/raw/aug_train.csv')` | chemin en dur | `data_loader.py` + `config.yaml` | `load_train`, `read_csv` |
| `df.info()`, `isnull().sum()` | exploration jetable | `visualization.py` | `plot_missing_values` |
| 8 × `df[col].fillna('Unknown')` | code dupliqué | `features.py` | `build_preprocessor` (`SimpleImputer(constant)`) |
| `def f(x)` + `apply` sur `experience` | fonction non typée, médiane sur tout le jeu | `preprocessing.py` | `parse_experience` (sans état) ; médiane dans le `Pipeline` |
| `replace({'never':0,'>4':5})` | idem | `preprocessing.py` | `parse_last_new_job` |
| `cdi * 100` | **non idempotent** | supprimé | on garde l'échelle d'origine (0–1), contrôlée par Pydantic |
| `pd.get_dummies(...)` sur tout `df2` | fuite + colonnes différentes sur `test` | `features.py` | `OneHotEncoder(handle_unknown=...)` dans le `Pipeline` |
| `StandardScaler().fit_transform(X)` avant le split | **fuite de données** | `features.py` | `StandardScaler` dans le `Pipeline` |
| `train_test_split(..., 0.2, 42)` | valeurs magiques | `model.py` + `config.yaml` | `split_train_valid`, `model.test_size`, `project.random_seed` |
| `RandomForestClassifier(n_estimators=100)` | pas de graine | `model.py` | `build_estimator`, `build_pipeline` |
| `accuracy_score` seul | métrique trompeuse | `evaluation.py` | `evaluate_classifier` (ROC-AUC, PR-AUC, F1…) |
| `plt.hist(...)` | pas de titre ni d'axes | `visualization.py` | 12 fonctions `plot_*` |
| `x = 5`, `toto = df2.shape` | variables parasites | supprimé | — |
| `test = pd.read_csv(...)  # TODO` | prédiction impossible | `pipeline.py` | `run_prediction` |
| *(absent)* | aucune validation | `schemas.py` | `validate_dataframe` |

## 3. Les deux gestionnaires de dépendances

Le `pyproject.toml` fourni suit le standard **PEP 621** : il fonctionne avec **uv** tel quel.

```bash
uv sync --extra dev        # crée .venv, résout, écrit uv.lock (à commiter)
uv run pytest              # exécute dans l'environnement du projet
uv add scikit-learn        # ajoute une dépendance
```

Avec **Poetry** (2.x), le même bloc `[project]` est lu directement (vérifié avec `poetry check` et `poetry install --dry-run`) :

```bash
poetry install --extras dev
poetry run pytest
poetry add scikit-learn
```

Dans les deux cas, le **fichier de verrouillage** (`uv.lock` / `poetry.lock`) fige les versions exactes : c'est lui qui garantit « ça marche aussi chez toi ». Le fichier `uv.lock` est fourni (généré avec `uv lock`, 144 paquets résolus) ; pour Poetry, génère le tien avec `poetry lock`. Dans les deux cas, ce fichier se **commite**.

## 4. Règles de refactorisation retenues

- Une fonction fait **une** chose et a un **nom-verbe** (`parse_experience`, `build_preprocessor`).
- Une fonction **ne modifie pas** ses arguments (`df.copy()` en entrée).
- Aucune valeur « magique » dans le code : tout vient de la configuration.
- Ce qui **apprend** des données (médiane, moyenne, catégories) va **dans** le `Pipeline` ; ce qui applique une règle fixe va dans `preprocessing.py`.
- Les `print` deviennent des `logger.info`.
- Le notebook final ne contient que des **appels** et des **commentaires de résultats**.

## 5. Vérifier que la refactorisation est réussie

```bash
pytest                       # 86 tests : schéma, config, nettoyage, modèle, pipeline, CLI
ruff check src tests         # style et erreurs courantes
mypy src                     # cohérence des types
python -m hr_pipeline train  # même ROC-AUC à chaque exécution (graine fixée)
```
